﻿namespace DoAnCoSo
{
    partial class Caidat
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnTaikhoan = new Guna.UI2.WinForms.Guna2Button();
            this.btnThoat = new Guna.UI2.WinForms.Guna2Button();
            this.btnTrangchu = new Guna.UI2.WinForms.Guna2Button();
            this.btnKhachhang = new Guna.UI2.WinForms.Guna2Button();
            this.btnNhanvien = new Guna.UI2.WinForms.Guna2Button();
            this.dgvKh = new System.Windows.Forms.DataGridView();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.dgvNv = new System.Windows.Forms.DataGridView();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.dgvTk = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvKh)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvNv)).BeginInit();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTk)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Pink;
            this.panel1.Controls.Add(this.btnTaikhoan);
            this.panel1.Controls.Add(this.btnThoat);
            this.panel1.Controls.Add(this.btnTrangchu);
            this.panel1.Controls.Add(this.btnKhachhang);
            this.panel1.Controls.Add(this.btnNhanvien);
            this.panel1.Location = new System.Drawing.Point(13, 112);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(209, 581);
            this.panel1.TabIndex = 2;
            // 
            // btnTaikhoan
            // 
            this.btnTaikhoan.BorderRadius = 15;
            this.btnTaikhoan.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnTaikhoan.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnTaikhoan.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnTaikhoan.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnTaikhoan.FillColor = System.Drawing.Color.LightCoral;
            this.btnTaikhoan.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTaikhoan.ForeColor = System.Drawing.Color.White;
            this.btnTaikhoan.HoverState.ForeColor = System.Drawing.Color.Pink;
            this.btnTaikhoan.Image = global::DoAnCoSo.Properties.Resources.phong;
            this.btnTaikhoan.Location = new System.Drawing.Point(-42, 252);
            this.btnTaikhoan.Margin = new System.Windows.Forms.Padding(4);
            this.btnTaikhoan.Name = "btnTaikhoan";
            this.btnTaikhoan.Size = new System.Drawing.Size(213, 68);
            this.btnTaikhoan.TabIndex = 9;
            this.btnTaikhoan.Text = "Tài khoản";
            this.btnTaikhoan.Click += new System.EventHandler(this.btnTaikhoan_Click);
            // 
            // btnThoat
            // 
            this.btnThoat.BorderRadius = 15;
            this.btnThoat.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnThoat.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnThoat.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnThoat.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnThoat.FillColor = System.Drawing.Color.LightCoral;
            this.btnThoat.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThoat.ForeColor = System.Drawing.Color.White;
            this.btnThoat.HoverState.ForeColor = System.Drawing.Color.Pink;
            this.btnThoat.Image = global::DoAnCoSo.Properties.Resources.THOAT;
            this.btnThoat.Location = new System.Drawing.Point(-42, 478);
            this.btnThoat.Margin = new System.Windows.Forms.Padding(4);
            this.btnThoat.Name = "btnThoat";
            this.btnThoat.Size = new System.Drawing.Size(213, 68);
            this.btnThoat.TabIndex = 7;
            this.btnThoat.Text = "Thoát";
            // 
            // btnTrangchu
            // 
            this.btnTrangchu.BorderRadius = 15;
            this.btnTrangchu.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnTrangchu.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnTrangchu.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnTrangchu.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnTrangchu.FillColor = System.Drawing.Color.LightCoral;
            this.btnTrangchu.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTrangchu.ForeColor = System.Drawing.Color.White;
            this.btnTrangchu.HoverState.ForeColor = System.Drawing.Color.Pink;
            this.btnTrangchu.Image = global::DoAnCoSo.Properties.Resources.pngtree_home_vector_icon_png_image_5152511;
            this.btnTrangchu.ImageSize = new System.Drawing.Size(30, 30);
            this.btnTrangchu.Location = new System.Drawing.Point(-42, 20);
            this.btnTrangchu.Margin = new System.Windows.Forms.Padding(4);
            this.btnTrangchu.Name = "btnTrangchu";
            this.btnTrangchu.Size = new System.Drawing.Size(213, 68);
            this.btnTrangchu.TabIndex = 1;
            this.btnTrangchu.Text = "Trang chủ";
            this.btnTrangchu.Click += new System.EventHandler(this.btnTrangchu_Click);
            // 
            // btnKhachhang
            // 
            this.btnKhachhang.BorderRadius = 15;
            this.btnKhachhang.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnKhachhang.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnKhachhang.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnKhachhang.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnKhachhang.FillColor = System.Drawing.Color.LightCoral;
            this.btnKhachhang.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnKhachhang.ForeColor = System.Drawing.Color.White;
            this.btnKhachhang.HoverState.ForeColor = System.Drawing.Color.Pink;
            this.btnKhachhang.Image = global::DoAnCoSo.Properties.Resources.khach;
            this.btnKhachhang.Location = new System.Drawing.Point(-42, 142);
            this.btnKhachhang.Margin = new System.Windows.Forms.Padding(4);
            this.btnKhachhang.Name = "btnKhachhang";
            this.btnKhachhang.Size = new System.Drawing.Size(213, 68);
            this.btnKhachhang.TabIndex = 3;
            this.btnKhachhang.Text = "Khách hàng";
            this.btnKhachhang.Click += new System.EventHandler(this.btnKhachhang_Click);
            // 
            // btnNhanvien
            // 
            this.btnNhanvien.BorderRadius = 15;
            this.btnNhanvien.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnNhanvien.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnNhanvien.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnNhanvien.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnNhanvien.FillColor = System.Drawing.Color.LightCoral;
            this.btnNhanvien.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNhanvien.ForeColor = System.Drawing.Color.White;
            this.btnNhanvien.HoverState.ForeColor = System.Drawing.Color.Pink;
            this.btnNhanvien.Image = global::DoAnCoSo.Properties.Resources.NV;
            this.btnNhanvien.Location = new System.Drawing.Point(-42, 365);
            this.btnNhanvien.Margin = new System.Windows.Forms.Padding(4);
            this.btnNhanvien.Name = "btnNhanvien";
            this.btnNhanvien.Size = new System.Drawing.Size(213, 68);
            this.btnNhanvien.TabIndex = 8;
            this.btnNhanvien.Text = "Nhân viên";
            this.btnNhanvien.Click += new System.EventHandler(this.btnNhanvien_Click);
            // 
            // dgvKh
            // 
            this.dgvKh.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvKh.Location = new System.Drawing.Point(18, 21);
            this.dgvKh.Name = "dgvKh";
            this.dgvKh.RowHeadersWidth = 51;
            this.dgvKh.RowTemplate.Height = 24;
            this.dgvKh.Size = new System.Drawing.Size(343, 538);
            this.dgvKh.TabIndex = 3;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.dgvKh);
            this.groupBox1.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(247, 111);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(382, 582);
            this.groupBox1.TabIndex = 6;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Thông tin khách hàng";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.dgvNv);
            this.groupBox2.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold);
            this.groupBox2.Location = new System.Drawing.Point(649, 112);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(382, 582);
            this.groupBox2.TabIndex = 7;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Thông tin nhân viên";
            // 
            // dgvNv
            // 
            this.dgvNv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvNv.Location = new System.Drawing.Point(18, 21);
            this.dgvNv.Name = "dgvNv";
            this.dgvNv.RowHeadersWidth = 51;
            this.dgvNv.RowTemplate.Height = 24;
            this.dgvNv.Size = new System.Drawing.Size(343, 538);
            this.dgvNv.TabIndex = 3;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.dgvTk);
            this.groupBox3.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold);
            this.groupBox3.Location = new System.Drawing.Point(1053, 111);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(382, 582);
            this.groupBox3.TabIndex = 8;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Thông tin tài khoản";
            // 
            // dgvTk
            // 
            this.dgvTk.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTk.Location = new System.Drawing.Point(18, 21);
            this.dgvTk.Name = "dgvTk";
            this.dgvTk.RowHeadersWidth = 51;
            this.dgvTk.RowTemplate.Height = 24;
            this.dgvTk.Size = new System.Drawing.Size(343, 538);
            this.dgvTk.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 25.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(306, 49);
            this.label1.TabIndex = 9;
            this.label1.Text = "Quản lý cài đặt";
            // 
            // Caidat
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1436, 818);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.panel1);
            this.Name = "Caidat";
            this.Text = "Cài đặt";
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvKh)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvNv)).EndInit();
            this.groupBox3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvTk)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private Guna.UI2.WinForms.Guna2Button btnThoat;
        private Guna.UI2.WinForms.Guna2Button btnKhachhang;
        private Guna.UI2.WinForms.Guna2Button btnNhanvien;
        private Guna.UI2.WinForms.Guna2Button btnTrangchu;
        private Guna.UI2.WinForms.Guna2Button btnTaikhoan;
        private System.Windows.Forms.DataGridView dgvKh;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.DataGridView dgvNv;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.DataGridView dgvTk;
        private System.Windows.Forms.Label label1;
    }
}
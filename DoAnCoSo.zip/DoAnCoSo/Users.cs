﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoAnCoSo
{
    public class Users
    {
        public static string Ten_Tai_Khoan { get; set; }
        public static string Nhom_Quyen { get; set; }
    }
}

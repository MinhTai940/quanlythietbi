﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace DoAnCoSo
{
    public partial class Sanpham : Form
    {
        string connectionString = "Data Source=DESKTOP-DL8SVNN\\PHUONGANH;Initial Catalog=QuanLyThoiTrangNu;User ID=sa;Password=12345678;Integrated Security=True";
        public Sanpham()
        {
            InitializeComponent();
            Hienthithongsanpham();
        }
        private void Hienthithongsanpham()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT * FROM San_Pham";

                    using (SqlDataAdapter adapter = new SqlDataAdapter(query, connection))
                    {
                        DataSet dataSet = new DataSet();
                        adapter.Fill(dataSet);
                        dgvHienthithongtinsp.DataSource = dataSet.Tables[0];
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi hiển thị danh sách sản phẩm: " + ex.Message);
            }
        }

        private void btnThemsp_Click(object sender, EventArgs e)
        {
            try
            {
                string maSanPham = txtMasanpham.Text.Trim();
                string tenSanPham = txtTensanpham.Text.Trim();
                string kichThuoc = txtKichthuoc.Text.Trim();
                string maTheLoai = txtMatheloai.Text.Trim();
                decimal giaBan = Convert.ToDecimal(txtGiaban.Text.Trim());
                string moTa = txtMota.Text.Trim();
                string mauSac = txtMausac.Text.Trim();
                int soLuongTon = Convert.ToInt32(txtSoluongton.Text.Trim());

                if (string.IsNullOrEmpty(maSanPham) || string.IsNullOrEmpty(tenSanPham) || string.IsNullOrEmpty(kichThuoc) || string.IsNullOrEmpty(maTheLoai) || string.IsNullOrEmpty(txtGiaban.Text) || string.IsNullOrEmpty(moTa) || string.IsNullOrEmpty(mauSac) || string.IsNullOrEmpty(txtSoluongton.Text))
                {
                    MessageBox.Show("Vui lòng nhập đầy đủ thông tin bắt buộc!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    string checkQuery = "SELECT COUNT(*) FROM San_Pham WHERE Ma_San_Pham = @Ma_San_Pham";
                    using (SqlCommand checkCommand = new SqlCommand(checkQuery, connection))
                    {
                        checkCommand.Parameters.AddWithValue("@Ma_San_Pham", maSanPham);
                        int count = (int)checkCommand.ExecuteScalar();
                        if (count > 0)
                        {
                            MessageBox.Show("Mã sản phẩm đã tồn tại! Vui lòng nhập mã khác.");
                            return;
                        }
                    }

                    string query = "INSERT INTO San_Pham (Ma_San_Pham, Ten_San_Pham, Ma_The_Loai, Kich_Thuoc, Mau_Sac, So_Luong_Ton, Gia_Ban, Mo_Ta ) " +
                                    "VALUES (@Ma_San_Pham, @Ten_San_Pham, @Ma_The_Loai, @Kich_Thuoc, @Mau_Sac, @So_Luong_Ton, @Gia_Ban, @Mo_Ta)";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@Ma_San_Pham", maSanPham);
                        command.Parameters.AddWithValue("@Ten_San_Pham", tenSanPham);
                        command.Parameters.AddWithValue("@Ma_The_Loai", maTheLoai);
                        command.Parameters.AddWithValue("@Kich_Thuoc", kichThuoc);
                        command.Parameters.AddWithValue("@Mau_Sac", mauSac);
                        command.Parameters.AddWithValue("@So_Luong_Ton", soLuongTon);
                        command.Parameters.AddWithValue("@Gia_Ban", giaBan);
                        command.Parameters.AddWithValue("@Mo_Ta", moTa);
                        command.ExecuteNonQuery();
                    }
                    MessageBox.Show("Thêm sản phẩm thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Hienthithongsanpham();
                    ClearFormSanpham();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi thêm sản phẩm: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void ClearFormSanpham()
        {
            txtMasanpham.Text = "";
            txtTensanpham.Text = "";
            txtKichthuoc.Text = "";
            txtMatheloai.Text = "";
            txtGiaban.Text = "";
            txtMota.Text = "";
            txtMausac.Text = "";
            txtSoluongton.Text = "";

            txtMasanpham.ReadOnly = false;
        }

        private void btnXoasp_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvHienthithongtinsp.SelectedRows.Count == 0)
                {
                    MessageBox.Show("Vui lòng chọn sản phẩm cần xóa!");
                    return;
                }
                DialogResult result = MessageBox.Show("Bạn có chắc chắn muốn xóa dữ liệu không?", "Xác nhận xóa", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    int maSanPham = Convert.ToInt32(dgvHienthithongtinsp.SelectedRows[0].Cells["Ma_San_Pham"].Value.ToString());
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();

                        string query = "DELETE FROM San_Pham WHERE Ma_San_Pham = @Ma_San_Pham";
                        using (SqlCommand command = new SqlCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("@Ma_San_Pham", maSanPham);
                            command.ExecuteNonQuery();
                        }
                    }
                    MessageBox.Show("Xóa dữ liệu thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Hienthithongsanpham();
                    ClearFormSanpham();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi xóa dữ liệu: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnSuasp_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvHienthithongtinsp.SelectedRows.Count == 0)
                {
                    MessageBox.Show("Vui lòng chọn sản phẩm cần sửa!");
                    return;
                }
                DialogResult result = MessageBox.Show("Bạn có chắc chắn muốn sửa dữ liệu không?", "Xác nhận sửa", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    string maSanPham = dgvHienthithongtinsp.SelectedRows[0].Cells["Ma_San_Pham"].Value.ToString();
                    string tenSanPham = txtTensanpham.Text.Trim();
                    string kichThuoc = txtKichthuoc.Text.Trim();
                    string maTheLoai = txtMatheloai.Text.Trim();
                    decimal giaBan = Convert.ToDecimal(txtGiaban.Text.Trim());
                    string moTa = txtMota.Text.Trim();
                    string mauSac = txtMausac.Text.Trim();
                    int soLuongTon = Convert.ToInt32(txtSoluongton.Text.Trim());

                    if (string.IsNullOrEmpty(maSanPham) || string.IsNullOrEmpty(tenSanPham) || string.IsNullOrEmpty(kichThuoc) || string.IsNullOrEmpty(maTheLoai) || string.IsNullOrEmpty(txtGiaban.Text) || string.IsNullOrEmpty(moTa) || string.IsNullOrEmpty(mauSac) || string.IsNullOrEmpty(txtSoluongton.Text))
                    {
                        MessageBox.Show("Vui lòng nhập đầy đủ thông tin bắt buộc!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();

                        string query = "UPDATE San_Pham SET Ten_San_Pham = @Ten_San_Pham, Ma_The_Loai = @Ma_The_Loai, Kich_Thuoc = @Kich_Thuoc, Mau_Sac = @Mau_Sac, So_Luong_Ton = @So_Luong_Ton, Gia_Ban = @Gia_Ban, Mo_Ta = @Mo_Ta " +
                                       "WHERE Ma_San_Pham = @Ma_San_Pham";
                        using (SqlCommand command = new SqlCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("@Ma_San_Pham", maSanPham);
                            command.Parameters.AddWithValue("@Ten_San_Pham", tenSanPham);
                            command.Parameters.AddWithValue("@Kich_Thuoc", kichThuoc);
                            command.Parameters.AddWithValue("@Ma_The_Loai", maTheLoai);
                            command.Parameters.AddWithValue("@Gia_Ban", giaBan);
                            command.Parameters.AddWithValue("@Mo_Ta", moTa);
                            command.Parameters.AddWithValue("@Mau_Sac", mauSac);
                            command.Parameters.AddWithValue("@So_Luong_Ton", soLuongTon);
                            command.ExecuteNonQuery();
                        }
                        MessageBox.Show("Sửa dữ liệu thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        Hienthithongsanpham();
                        ClearFormSanpham();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi sửa dữ liệu: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void btnTimkiemsp_Click(object sender, EventArgs e)
        {
            try
            {
                string maSanPham = txtTimkiemsanpham.Text.Trim();
                if (string.IsNullOrEmpty(maSanPham))
                {
                    MessageBox.Show("Vui lòng nhập mã sản phẩm để tìm kiếm!");
                    return;
                }

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    string query = "SELECT sp.Ma_San_Pham, sp.Ten_San_Pham, sp.Ma_The_Loai, sp.Kich_Thuoc, sp.Mau_Sac, sp.So_Luong_Ton, sp.Gia_Ban, sp.Mo_Ta " +
                                   "FROM San_Pham sp " +
                                   "WHERE sp.Ma_San_Pham LIKE @Ma_San_Pham";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@Ma_San_Pham", "%" + maSanPham + "%");
                        using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                        {
                            DataSet dataSet = new DataSet();
                            adapter.Fill(dataSet);
                            dgvHienthithongtinsp.DataSource = dataSet.Tables[0];
                        }
                    }
                }
                if (dgvHienthithongtinsp.Rows.Count == 0 || dgvHienthithongtinsp.Rows[0].IsNewRow)
                {
                    MessageBox.Show("Không tìm thấy mã sản phẩm: " + maSanPham + "!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi tìm kiếm dữ liệu: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void btnTailaisp_Click(object sender, EventArgs e)
        {
            Hienthithongsanpham();
            ClearFormSanpham();
            txtTimkiemsanpham.Text = "";
        }

        private void btnQuaylaisp_Click(object sender, EventArgs e)
        {
            Caidat caidat = new Caidat();
            caidat.Show();
        }

        private void dgvHienthithongtinsp_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvHienthithongtinsp.SelectedRows.Count == 0) return;

            DataGridViewRow row = dgvHienthithongtinsp.SelectedRows[0];

            txtMasanpham.Text = row.Cells["Ma_San_Pham"].Value?.ToString();
            txtTensanpham.Text = row.Cells["Ten_San_Pham"].Value?.ToString();
            txtKichthuoc.Text = row.Cells["Kich_Thuoc"].Value?.ToString();
            txtMatheloai.Text = row.Cells["Ma_The_Loai"].Value?.ToString();
            txtGiaban.Text = row.Cells["Gia_Ban"].Value?.ToString();
            txtMota.Text = row.Cells["Mo_Ta"].Value?.ToString();
            txtMausac.Text = row.Cells["Mau_Sac"].Value?.ToString();
            txtSoluongton.Text = row.Cells["So_Luong_Ton"].Value?.ToString();

            txtMasanpham.ReadOnly = true;
        }
    }
}

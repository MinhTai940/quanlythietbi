﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DoAnCoSo
{
    public partial class DanhMucSanPham : Form
    {
        string connectionString = "Data Source=DESKTOP-DL8SVNN\\PHUONGANH;Initial Catalog=QuanLyThoiTrangNu;User ID=sa;Password=12345678;Integrated Security=True";
        public DanhMucSanPham()
        {
            InitializeComponent();
            Hienthithongdanhmucsanpham();
        }
        private void Hienthithongdanhmucsanpham()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT * FROM Danh_Muc_San_Pham";

                    using (SqlDataAdapter adapter = new SqlDataAdapter(query, connection))
                    {
                        DataSet dataSet = new DataSet();
                        adapter.Fill(dataSet);
                        dgvDanhMucSanPham.DataSource = dataSet.Tables[0];
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi hiển thị danh sách thư mục sản phẩm: " + ex.Message);
            }
        }

        private void btnThemdm_Click(object sender, EventArgs e)
        {
            try
            {
                string maDanhMuc = txtMadanhmuc.Text.Trim();
                string tenDanhMuc = txtTendanhmuc.Text.Trim();
                string moTa = txtMotadanhmuc.Text.Trim();    

                if (string.IsNullOrEmpty(maDanhMuc) || string.IsNullOrEmpty(tenDanhMuc) || string.IsNullOrEmpty(moTa))
                {
                    MessageBox.Show("Vui lòng nhập đầy đủ thông tin bắt buộc!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    string checkQuery = "SELECT COUNT(*) FROM Danh_Muc_San_Pham WHERE Ma_Danh_Muc = @Ma_Danh_Muc";
                    using (SqlCommand checkCommand = new SqlCommand(checkQuery, connection))
                    {
                        checkCommand.Parameters.AddWithValue("@Ma_Danh_Muc", maDanhMuc);
                        int count = (int)checkCommand.ExecuteScalar();
                        if (count > 0)
                        {
                            MessageBox.Show("Mã danh mục đã tồn tại! Vui lòng nhập mã khác.");
                            return;
                        }
                    }

                    string query = "INSERT INTO Danh_Muc_San_Pham (Ma_Danh_Muc, Ten_Danh_Muc, Mo_Ta) " +
                                    "VALUES (@Ma_Danh_Muc, @Ten_Danh_Muc, @Mo_Ta)";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@Ma_Danh_Muc", maDanhMuc);
                        command.Parameters.AddWithValue("@Ten_Danh_Muc", tenDanhMuc);
                        command.Parameters.AddWithValue("@Mo_Ta", moTa);
                        command.ExecuteNonQuery();
                    }
                    MessageBox.Show("Thêm danh mục sản phẩm thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Hienthithongdanhmucsanpham();
                    ClearFormDanhmucsanpham();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi thêm danh mục sản phẩm: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void ClearFormDanhmucsanpham()
        {
            txtMadanhmuc.Text = "";
            txtTendanhmuc.Text = "";
            txtMotadanhmuc.Text = "";

            txtMadanhmuc.Enabled = false;
        }

        private void btnXoadm_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvDanhMucSanPham.SelectedRows.Count == 0)
                {
                    MessageBox.Show("Vui lòng chọn danh mục sản phẩm cần xóa!");
                    return;
                }
                DialogResult result = MessageBox.Show("Bạn có chắc chắn muốn xóa dữ liệu không?", "Xác nhận xóa", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    string maDanhMuc = dgvDanhMucSanPham.SelectedRows[0].Cells["Ma_Danh_Muc"].Value.ToString();
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();

                        string query = "DELETE FROM Danh_Muc_San_Pham WHERE Ma_Danh_Muc = @Ma_Danh_Muc";
                        using (SqlCommand command = new SqlCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("@Ma_Danh_Muc", maDanhMuc);
                            command.ExecuteNonQuery();
                        }
                    }
                    MessageBox.Show("Xóa dữ liệu thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Hienthithongdanhmucsanpham();
                    ClearFormDanhmucsanpham();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi xóa dữ liệu: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnSuadm_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvDanhMucSanPham.SelectedRows.Count == 0)
                {
                    MessageBox.Show("Vui lòng chọn danh mục sản phẩm cần sửa!");
                    return;
                }
                DialogResult result = MessageBox.Show("Bạn có chắc chắn muốn sửa dữ liệu không?", "Xác nhận sửa", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    string maDanhMuc = dgvDanhMucSanPham.SelectedRows[0].Cells["Ma_Danh_Muc"].Value.ToString();
                    string tenDanhMuc = txtTendanhmuc.Text.Trim();
                    string moTa = txtMotadanhmuc.Text.Trim();

                    if (string.IsNullOrEmpty(maDanhMuc) || string.IsNullOrEmpty(tenDanhMuc) || string.IsNullOrEmpty(moTa))
                    {
                        MessageBox.Show("Vui lòng nhập đầy đủ thông tin bắt buộc!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();

                        string query = "UPDATE Danh_Muc_San_Pham SET Ten_Danh_Muc = @Ten_Danh_Muc, Mo_Ta = @Mo_Ta " +
                                       "WHERE Ma_Danh_Muc = @Ma_Danh_Muc";
                        using (SqlCommand command = new SqlCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("@Ma_Danh_Muc", maDanhMuc);
                            command.Parameters.AddWithValue("@Ten_Danh_Muc", tenDanhMuc);
                            command.Parameters.AddWithValue("@Mo_Ta", moTa);
                            command.ExecuteNonQuery();
                        }
                        MessageBox.Show("Sửa dữ liệu thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        Hienthithongdanhmucsanpham();
                        ClearFormDanhmucsanpham();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi sửa dữ liệu: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private void dgvDanhMucSanPham_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvDanhMucSanPham.SelectedRows.Count == 0) return;

            DataGridViewRow row = dgvDanhMucSanPham.SelectedRows[0];

            txtMadanhmuc.Text = row.Cells["Ma_Danh_Muc"].Value?.ToString();
            txtTendanhmuc.Text = row.Cells["Ten_Danh_Muc"].Value?.ToString();
            txtMotadanhmuc.Text = row.Cells["Mo_Ta"].Value?.ToString();

            txtMadanhmuc.ReadOnly = true;
        }
    }
}

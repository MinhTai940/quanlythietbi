﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DoAnCoSo
{
    public partial class Trangchu : Form
    {
        private string quyenNguoiDung;

        public Trangchu(string nhomQuyen)
        {
            InitializeComponent();
            quyenNguoiDung = nhomQuyen;
        }
        private void PhanQuyenNguoiDung()
        {
            if (quyenNguoiDung == "nhanvien")
            {
                btnNhacungcap.Visible = false;
                

                // Nếu muốn ẩn luôn thì dùng:
                // btnNhaCungCap.Visible = false;
            }
        }
        private void Trangchu_Load(object sender, EventArgs e)
        {
            PhanQuyenNguoiDung();
        }
        private void btnSanpham_Click(object sender, EventArgs e)
        {
            Sanpham sanPham = new Sanpham();
            sanPham.ShowDialog();
        }

        private void btnHoadon_Click(object sender, EventArgs e)
        {
            Hoadon hoadon = new Hoadon();
            hoadon.ShowDialog();
        }

        private void btnChitiethoadon_Click(object sender, EventArgs e)
        {
            Chitiethoadon chitiethoadon = new Chitiethoadon();
            chitiethoadon.ShowDialog();
        }

        private void btnNhacungcap_Click(object sender, EventArgs e)
        {
            Nhacungcap nhacungcap = new Nhacungcap();
            nhacungcap.ShowDialog();
        }

        private void btnCaidat_Click(object sender, EventArgs e)
        {
            Caidat caidat = new Caidat();
            caidat.ShowDialog();
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Bạn có chắc chắn muốn thoát ứng dụng không?",
                "Xác nhận",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning);
            if (result == DialogResult.Yes)
            {
                Application.Exit(); // Thoát toàn bộ ứng dụng
            }
        }

        
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DoAnCoSo
{
    public partial class Nhanvien : Form
    {
        string connectionString = "Data Source=DESKTOP-DL8SVNN\\PHUONGANH; Initial Catalog=QuanLyThoiTrangNu; User ID=sa; Password=12345678; Integrated Security=True";
        public Nhanvien()
        {
            InitializeComponent();
            Hienthithongnhanvien();
        }
        private void Hienthithongnhanvien()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT * FROM Nhan_Vien";

                    using (SqlDataAdapter adapter = new SqlDataAdapter(query, connection))
                    {
                        DataSet dataSet = new DataSet();
                        adapter.Fill(dataSet);
                        dgvHienthithongtinnv.DataSource = dataSet.Tables[0];
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi hiển thị danh sách nhân viên: " + ex.Message);
            }
        
        }

        private void btnThemnv_Click(object sender, EventArgs e)
        {
            try
            {
                string maNhanVien = txtManhanvien.Text.Trim();
                string tenNhanVien = txtTennhanvien.Text.Trim();
                string matKhau = txtMatkhaunhanvien.Text.Trim();
                string vaiTro = txtVaitro.Text.Trim();
                string soDienThoai = txtSdtnhanvien.Text.Trim();
                string email = txtEmailnhanvien.Text.Trim();

                if (string.IsNullOrEmpty(maNhanVien) || string.IsNullOrEmpty(tenNhanVien) || string.IsNullOrEmpty(matKhau) || string.IsNullOrEmpty(vaiTro) || string.IsNullOrEmpty(soDienThoai) || string.IsNullOrEmpty(email))
                {
                    MessageBox.Show("Vui lòng nhập đầy đủ thông tin bắt buộc!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // Kiểm tra định dạng số điện thoại: chỉ chứa số và độ dài từ 9-11
                if (!System.Text.RegularExpressions.Regex.IsMatch(soDienThoai, @"^\d{9,11}$"))
                {
                    MessageBox.Show("Số điện thoại không hợp lệ! Vui lòng nhập 9-11 chữ số.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // Kiểm tra định dạng email
                if (!System.Text.RegularExpressions.Regex.IsMatch(email, @"^[^@\s]+@[^@\s]+\.[^@\s]+$"))
                {
                    MessageBox.Show("Email không hợp lệ! Vui lòng nhập đúng định dạng (vd: ten@gmail.com).", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    string checkQuery = "SELECT COUNT(*) FROM Nhan_Vien WHERE Ma_Nhan_Vien = @Ma_Nhan_Vien";
                    using (SqlCommand checkCommand = new SqlCommand(checkQuery, connection))
                    {
                        checkCommand.Parameters.AddWithValue("@Ma_Nhan_Vien", maNhanVien);
                        int count = (int)checkCommand.ExecuteScalar();
                        if (count > 0)
                        {
                            MessageBox.Show("Mã nhân viên đã tồn tại! Vui lòng nhập mã khác.");
                            return;
                        }
                    }

                    string query = "INSERT INTO Nhan_Vien (Ma_Nhan_Vien, Mat_Khau, Vai_Tro, Ho_Ten, Email, So_Dien_Thoai) " +
                                    "VALUES (@Ma_Nhan_Vien, @Mat_Khau, @Vai_Tro, @Ho_Ten, @Email, @So_Dien_Thoai)";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@Ma_Nhan_Vien", maNhanVien);
                        command.Parameters.AddWithValue("@Mat_Khau", matKhau);
                        command.Parameters.AddWithValue("@Vai_Tro", vaiTro);
                        command.Parameters.AddWithValue("@Ho_Ten", tenNhanVien);
                        command.Parameters.AddWithValue("@So_Dien_Thoai", soDienThoai);
                        command.Parameters.AddWithValue("@Email", email);
                        command.ExecuteNonQuery();
                    }
                    MessageBox.Show("Thêm nhân viên thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Hienthithongnhanvien();
                    ClearFormNhanvien();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi thêm nhân viên: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void ClearFormNhanvien()
        {
            txtManhanvien.Text = "";
            txtMatkhaunhanvien.Text = "";
            txtVaitro.Text = "";
            txtTennhanvien.Text = "";
            txtSdtnhanvien.Text = "";
            txtEmailnhanvien.Text = "";

            txtManhanvien.ReadOnly = false;
        }

        private void btnXoanv_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvHienthithongtinnv.SelectedRows.Count == 0)
                {
                    MessageBox.Show("Vui lòng chọn nhân viên cần xóa!");
                    return;
                }
                DialogResult result = MessageBox.Show("Bạn có chắc chắn muốn xóa dữ liệu không?", "Xác nhận xóa", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    string maNhanVien = dgvHienthithongtinnv.SelectedRows[0].Cells["Ma_Nhan_Vien"].Value.ToString();
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();

                        string query = "DELETE FROM Nhan_Vien WHERE Ma_Nhan_Vien = @Ma_Nhan_Vien";
                        using (SqlCommand command = new SqlCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("@Ma_Nhan_Vien", maNhanVien);
                            command.ExecuteNonQuery();
                        }
                    }
                    MessageBox.Show("Xóa dữ liệu thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Hienthithongnhanvien();
                    ClearFormNhanvien();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi xóa dữ liệu: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnSuanv_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvHienthithongtinnv.SelectedRows.Count == 0)
                {
                    MessageBox.Show("Vui lòng chọn nhân viên cần sửa!");
                    return;
                }
                DialogResult result = MessageBox.Show("Bạn có chắc chắn muốn sửa dữ liệu không?", "Xác nhận sửa", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    string maNhanVien = dgvHienthithongtinnv.SelectedRows[0].Cells["Ma_Nhan_Vien"].Value.ToString();
                    string tenNhanVien = txtTennhanvien.Text.Trim();
                    string matKhau = txtMatkhaunhanvien.Text.Trim();
                    string vaiTro = txtVaitro.Text.Trim();
                    string soDienThoai = txtSdtnhanvien.Text.Trim();
                    string email = txtEmailnhanvien.Text.Trim();

                    if (string.IsNullOrEmpty(maNhanVien) || string.IsNullOrEmpty(tenNhanVien) || string.IsNullOrEmpty(matKhau) || string.IsNullOrEmpty(vaiTro) || string.IsNullOrEmpty(soDienThoai) || string.IsNullOrEmpty(email))
                    {
                        MessageBox.Show("Vui lòng nhập đầy đủ thông tin bắt buộc!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();

                        string query = "UPDATE Nhan_Vien SET Mat_Khau = @Mat_Khau, Vai_Tro = @Vai_Tro, Ho_Ten = @Ho_Ten, So_Dien_Thoai = @So_Dien_Thoai, Email = @Email " +
                                       "WHERE Ma_Nhan_Vien = @Ma_Nhan_Vien";
                        using (SqlCommand command = new SqlCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("@Ma_Nhan_Vien", maNhanVien);
                            command.Parameters.AddWithValue("@Mat_Khau", matKhau);
                            command.Parameters.AddWithValue("@Vai_Tro", vaiTro);
                            command.Parameters.AddWithValue("@Ho_Ten", tenNhanVien);
                            command.Parameters.AddWithValue("@So_Dien_Thoai", soDienThoai);
                            command.Parameters.AddWithValue("@Email", email);
                            command.ExecuteNonQuery();
                        }
                        MessageBox.Show("Sửa dữ liệu thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        Hienthithongnhanvien();
                        ClearFormNhanvien();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi sửa dữ liệu: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void btnTimKiemNhanVien_Click(object sender, EventArgs e)
        {
            try
            {
                string maNhanVien = txtTimkiemnhanvien.Text.Trim();
                if (string.IsNullOrEmpty(maNhanVien))
                {
                    MessageBox.Show("Vui lòng nhập mã nhân viên để tìm kiếm!");
                    return;
                }

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    string query = "SELECT nv.Ma_Nhan_Vien, nv.Mat_Khau, nv.Vai_Tro, nv.Ho_Ten, nv.So_Dien_Thoai, nv.Email " +
                                   "FROM Nhan_Vien nv " +
                                   "WHERE nv.Ma_Nhan_Vien LIKE @Ma_Nhan_Vien";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@Ma_Nhan_Vien", "%" + maNhanVien + "%");
                        using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                        {
                            DataSet dataSet = new DataSet();
                            adapter.Fill(dataSet);
                            dgvHienthithongtinnv.DataSource = dataSet.Tables[0];
                        }
                    }
                }
                if (dgvHienthithongtinnv.Rows.Count == 0 || dgvHienthithongtinnv.Rows[0].IsNewRow)
                {
                    MessageBox.Show("Không tìm thấy mã nhân viên: " + maNhanVien + "!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi tìm kiếm dữ liệu: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void btnTailainv_Click(object sender, EventArgs e)
        {
            Hienthithongnhanvien();
            ClearFormNhanvien();
            txtTimkiemnhanvien.Text = "";
        }

        private void btnQuaylainv_Click(object sender, EventArgs e)
        {
            Caidat caidat = new Caidat();
            caidat.Show();
        }

        private void dgvHienthithongtinnv_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvHienthithongtinnv.SelectedRows.Count == 0) return;

            DataGridViewRow row = dgvHienthithongtinnv.SelectedRows[0];

            txtManhanvien.Text = row.Cells["Ma_Nhan_Vien"].Value?.ToString();
            txtTennhanvien.Text = row.Cells["Ho_Ten"].Value?.ToString();
            txtMatkhaunhanvien.Text = row.Cells["Mat_Khau"].Value?.ToString();
            txtVaitro.Text = row.Cells["Vai_Tro"].Value?.ToString();
            txtSdtnhanvien.Text = row.Cells["So_Dien_Thoai"].Value?.ToString();
            txtEmailnhanvien.Text = row.Cells["Email"].Value?.ToString();

            txtManhanvien.ReadOnly = true;
        }
    }
}

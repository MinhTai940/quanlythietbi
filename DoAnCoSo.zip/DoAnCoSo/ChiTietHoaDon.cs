﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DoAnCoSo
{
    public partial class Chitiethoadon : Form
    {
        string connectionString = "Data Source=DESKTOP-T28R5TF\\SQLEXPRESS;Initial Catalog=QuanLyThoiTrangNu;User ID=sa;Password=123456;Integrated Security=True";

        public Chitiethoadon()
        {
            InitializeComponent();
            Hienthithongkhachhang();
        }

        private void Hienthithongkhachhang()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = @"
        SELECT 
            hd.Ma_Hoa_Don,
            kh.Ma_Khach_Hang,
            kh.Ho_Ten AS Ten_Khach_Hang,
            ncc.Ma_Nha_Cung_Cap,
            ncc.Ten_Nha_Cung_Cap,
            sp.Ma_San_Pham,
            sp.Ten_San_Pham,
            cthd.So_Luong,
            cthd.Don_Gia,
            cthd.Thanh_Tien
        FROM Hoa_Don hd
        JOIN Khach_Hang kh ON hd.Ma_Khach_Hang = kh.Ma_Khach_Hang
        JOIN Chi_Tiet_Hoa_Don cthd ON hd.Ma_Hoa_Don = cthd.Ma_Hoa_Don
        JOIN San_Pham sp ON cthd.Ma_San_Pham = sp.Ma_San_Pham
        JOIN Nha_Cung_Cap ncc ON sp.Ma_Nha_Cung_Cap = ncc.Ma_Nha_Cung_Cap";

                    using (SqlDataAdapter adapter = new SqlDataAdapter(query, connection))
                    {
                        DataSet dataSet = new DataSet();
                        adapter.Fill(dataSet);
                        dgvChitiethoadon.DataSource = dataSet.Tables[0];
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi hiển thị danh sách khách hàng: " + ex.Message);
            }
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DoAnCoSo
{
    public partial class Dangnhap : Form
    {
        string connectionString = "Data Source=DESKTOP-T28R5TF\\SQLEXPRESS;Initial Catalog=QuanLyThoiTrangNu;User ID=sa;Password=123456;Integrated Security=True";
        public Dangnhap()
        {
            InitializeComponent();
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnDangnhap_Click(object sender, EventArgs e)
        {
            string tentaikhoan = txtDangnhaptk.Text.Trim();
            string matkhau = txtMatkhau.Text.Trim();
            
            if(string.IsNullOrEmpty(tentaikhoan) || string.IsNullOrEmpty(matkhau))
            {
                MessageBox.Show("Vui lòng nhập đầy đủ tên đăng nhập và mật khẩu.");
                return;
            }    

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    string query = "SELECT COUNT(*) FROM Dang_Nhap WHERE Ten_Tai_Khoan=@TenTaiKhoan AND Mat_Khau=@MatKhau";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@TenTaiKhoan", tentaikhoan);
                    cmd.Parameters.AddWithValue("@MatKhau", matkhau);

                    int count = (int)cmd.ExecuteScalar();

                    if(count == 1)
                    {
                        MessageBox.Show("Đăng nhập thành công!");
                        Trangchu trangChu = new Trangchu();
                        trangChu.Show();
                        this.Hide();
                    }
                    else
                    {
                        MessageBox.Show("Tên đăng nhập hoặc mật khẩu không đúng.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Lỗi kết nối: " + ex.Message);
                }
            }
        }
    }
}

﻿namespace DoAnCoSo
{
    partial class Chitiethoadon
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnXuatfile = new Guna.UI2.WinForms.Guna2Button();
            this.btnThongke = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button2 = new Guna.UI2.WinForms.Guna2Button();
            this.dgvChitiethoadon = new System.Windows.Forms.DataGridView();
            this.txtSoluong = new System.Windows.Forms.TextBox();
            this.cmbMasanpham = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.cmbMahoadon = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.guna2GroupBox1 = new Guna.UI2.WinForms.Guna2GroupBox();
            this.txtThanhtien = new System.Windows.Forms.TextBox();
            this.txtDongia = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnPdf = new Guna.UI2.WinForms.Guna2Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvChitiethoadon)).BeginInit();
            this.guna2GroupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnXuatfile
            // 
            this.btnXuatfile.BorderRadius = 20;
            this.btnXuatfile.BorderThickness = 1;
            this.btnXuatfile.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnXuatfile.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnXuatfile.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnXuatfile.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnXuatfile.FillColor = System.Drawing.Color.LightCoral;
            this.btnXuatfile.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXuatfile.ForeColor = System.Drawing.Color.White;
            this.btnXuatfile.HoverState.BorderColor = System.Drawing.Color.LightCoral;
            this.btnXuatfile.HoverState.FillColor = System.Drawing.Color.White;
            this.btnXuatfile.HoverState.ForeColor = System.Drawing.Color.LightCoral;
            this.btnXuatfile.Location = new System.Drawing.Point(801, 461);
            this.btnXuatfile.Name = "btnXuatfile";
            this.btnXuatfile.Size = new System.Drawing.Size(200, 60);
            this.btnXuatfile.TabIndex = 47;
            this.btnXuatfile.Text = "Xuất file";
            // 
            // btnThongke
            // 
            this.btnThongke.BorderRadius = 20;
            this.btnThongke.BorderThickness = 1;
            this.btnThongke.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnThongke.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnThongke.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnThongke.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnThongke.FillColor = System.Drawing.Color.LightCoral;
            this.btnThongke.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThongke.ForeColor = System.Drawing.Color.White;
            this.btnThongke.HoverState.BorderColor = System.Drawing.Color.LightCoral;
            this.btnThongke.HoverState.FillColor = System.Drawing.Color.White;
            this.btnThongke.HoverState.ForeColor = System.Drawing.Color.LightCoral;
            this.btnThongke.Location = new System.Drawing.Point(151, 461);
            this.btnThongke.Name = "btnThongke";
            this.btnThongke.Size = new System.Drawing.Size(200, 60);
            this.btnThongke.TabIndex = 48;
            this.btnThongke.Text = "Thống kê";
            // 
            // guna2Button2
            // 
            this.guna2Button2.BorderRadius = 20;
            this.guna2Button2.BorderThickness = 1;
            this.guna2Button2.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button2.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button2.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button2.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button2.FillColor = System.Drawing.Color.LightCoral;
            this.guna2Button2.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button2.ForeColor = System.Drawing.Color.White;
            this.guna2Button2.HoverState.BorderColor = System.Drawing.Color.LightCoral;
            this.guna2Button2.HoverState.FillColor = System.Drawing.Color.White;
            this.guna2Button2.HoverState.ForeColor = System.Drawing.Color.LightCoral;
            this.guna2Button2.Location = new System.Drawing.Point(476, 461);
            this.guna2Button2.Name = "guna2Button2";
            this.guna2Button2.Size = new System.Drawing.Size(200, 60);
            this.guna2Button2.TabIndex = 49;
            this.guna2Button2.Text = "Thêm hóa đơn";
            // 
            // dgvChitiethoadon
            // 
            this.dgvChitiethoadon.BackgroundColor = System.Drawing.Color.White;
            this.dgvChitiethoadon.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvChitiethoadon.Location = new System.Drawing.Point(18, 540);
            this.dgvChitiethoadon.Name = "dgvChitiethoadon";
            this.dgvChitiethoadon.RowHeadersWidth = 51;
            this.dgvChitiethoadon.RowTemplate.Height = 24;
            this.dgvChitiethoadon.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvChitiethoadon.Size = new System.Drawing.Size(1412, 266);
            this.dgvChitiethoadon.TabIndex = 45;
            // 
            // txtSoluong
            // 
            this.txtSoluong.Location = new System.Drawing.Point(1035, 102);
            this.txtSoluong.Multiline = true;
            this.txtSoluong.Name = "txtSoluong";
            this.txtSoluong.Size = new System.Drawing.Size(350, 30);
            this.txtSoluong.TabIndex = 43;
            // 
            // cmbMasanpham
            // 
            this.cmbMasanpham.FormattingEnabled = true;
            this.cmbMasanpham.Location = new System.Drawing.Point(133, 184);
            this.cmbMasanpham.Name = "cmbMasanpham";
            this.cmbMasanpham.Size = new System.Drawing.Size(287, 27);
            this.cmbMasanpham.TabIndex = 42;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(454, 192);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(87, 19);
            this.label6.TabIndex = 41;
            this.label6.Text = "Thành tiền";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(454, 105);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(66, 19);
            this.label4.TabIndex = 40;
            this.label4.Text = "Đơn giá";
            // 
            // cmbMahoadon
            // 
            this.cmbMahoadon.FormattingEnabled = true;
            this.cmbMahoadon.Location = new System.Drawing.Point(133, 105);
            this.cmbMahoadon.Name = "cmbMahoadon";
            this.cmbMahoadon.Size = new System.Drawing.Size(287, 27);
            this.cmbMahoadon.TabIndex = 39;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(951, 105);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(74, 19);
            this.label3.TabIndex = 38;
            this.label3.Text = "Số lượng";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(27, 105);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(94, 19);
            this.label2.TabIndex = 37;
            this.label2.Text = "Mã hóa đơn";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(27, 184);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(105, 19);
            this.label9.TabIndex = 36;
            this.label9.Text = "Mã sản phẩm";
            // 
            // guna2GroupBox1
            // 
            this.guna2GroupBox1.Controls.Add(this.txtThanhtien);
            this.guna2GroupBox1.Controls.Add(this.txtDongia);
            this.guna2GroupBox1.Controls.Add(this.txtSoluong);
            this.guna2GroupBox1.Controls.Add(this.cmbMasanpham);
            this.guna2GroupBox1.Controls.Add(this.label6);
            this.guna2GroupBox1.Controls.Add(this.label4);
            this.guna2GroupBox1.Controls.Add(this.cmbMahoadon);
            this.guna2GroupBox1.Controls.Add(this.label3);
            this.guna2GroupBox1.Controls.Add(this.label2);
            this.guna2GroupBox1.Controls.Add(this.label9);
            this.guna2GroupBox1.CustomBorderColor = System.Drawing.Color.LightCoral;
            this.guna2GroupBox1.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.guna2GroupBox1.ForeColor = System.Drawing.Color.White;
            this.guna2GroupBox1.Location = new System.Drawing.Point(18, 123);
            this.guna2GroupBox1.Name = "guna2GroupBox1";
            this.guna2GroupBox1.Size = new System.Drawing.Size(1412, 314);
            this.guna2GroupBox1.TabIndex = 46;
            this.guna2GroupBox1.Text = "Thông Tin Chi Tiết Hóa Đơn";
            // 
            // txtThanhtien
            // 
            this.txtThanhtien.Location = new System.Drawing.Point(547, 189);
            this.txtThanhtien.Multiline = true;
            this.txtThanhtien.Name = "txtThanhtien";
            this.txtThanhtien.Size = new System.Drawing.Size(350, 30);
            this.txtThanhtien.TabIndex = 45;
            // 
            // txtDongia
            // 
            this.txtDongia.Location = new System.Drawing.Point(547, 102);
            this.txtDongia.Multiline = true;
            this.txtDongia.Name = "txtDongia";
            this.txtDongia.Size = new System.Drawing.Size(350, 30);
            this.txtDongia.TabIndex = 44;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label1.Location = new System.Drawing.Point(505, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(446, 61);
            this.label1.TabIndex = 50;
            this.label1.Text = "Quản lý chi tiết hóa đơn";
            // 
            // btnPdf
            // 
            this.btnPdf.BorderRadius = 20;
            this.btnPdf.BorderThickness = 1;
            this.btnPdf.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnPdf.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnPdf.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnPdf.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnPdf.FillColor = System.Drawing.Color.LightCoral;
            this.btnPdf.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPdf.ForeColor = System.Drawing.Color.White;
            this.btnPdf.HoverState.BorderColor = System.Drawing.Color.LightCoral;
            this.btnPdf.HoverState.FillColor = System.Drawing.Color.White;
            this.btnPdf.HoverState.ForeColor = System.Drawing.Color.LightCoral;
            this.btnPdf.Location = new System.Drawing.Point(1103, 461);
            this.btnPdf.Name = "btnPdf";
            this.btnPdf.Size = new System.Drawing.Size(200, 60);
            this.btnPdf.TabIndex = 51;
            this.btnPdf.Text = "File pdf";
            // 
            // Chitiethoadon
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1436, 818);
            this.Controls.Add(this.btnPdf);
            this.Controls.Add(this.btnXuatfile);
            this.Controls.Add(this.btnThongke);
            this.Controls.Add(this.guna2Button2);
            this.Controls.Add(this.dgvChitiethoadon);
            this.Controls.Add(this.guna2GroupBox1);
            this.Controls.Add(this.label1);
            this.Name = "Chitiethoadon";
            this.Text = "Chi tiết hóa đơn";
            ((System.ComponentModel.ISupportInitialize)(this.dgvChitiethoadon)).EndInit();
            this.guna2GroupBox1.ResumeLayout(false);
            this.guna2GroupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2Button btnXuatfile;
        private Guna.UI2.WinForms.Guna2Button btnThongke;
        private Guna.UI2.WinForms.Guna2Button guna2Button2;
        private System.Windows.Forms.DataGridView dgvChitiethoadon;
        private System.Windows.Forms.TextBox txtSoluong;
        private System.Windows.Forms.ComboBox cmbMasanpham;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cmbMahoadon;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label9;
        private Guna.UI2.WinForms.Guna2GroupBox guna2GroupBox1;
        private System.Windows.Forms.TextBox txtThanhtien;
        private System.Windows.Forms.TextBox txtDongia;
        private System.Windows.Forms.Label label1;
        private Guna.UI2.WinForms.Guna2Button btnPdf;
    }
}
﻿namespace DoAnCoSo
{
    partial class Trangchu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Trangchu));
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnNhacungcap = new Guna.UI2.WinForms.Guna2Button();
            this.btnThoat = new Guna.UI2.WinForms.Guna2Button();
            this.btnTrangchu = new Guna.UI2.WinForms.Guna2Button();
            this.btnCaidat = new Guna.UI2.WinForms.Guna2Button();
            this.btnChitiethoadon = new Guna.UI2.WinForms.Guna2Button();
            this.btnHoadon = new Guna.UI2.WinForms.Guna2Button();
            this.btnSanpham = new Guna.UI2.WinForms.Guna2Button();
            this.label1 = new System.Windows.Forms.Label();
            this.guna2PictureBox1 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Pink;
            this.panel1.Controls.Add(this.btnNhacungcap);
            this.panel1.Controls.Add(this.btnThoat);
            this.panel1.Controls.Add(this.btnTrangchu);
            this.panel1.Controls.Add(this.btnCaidat);
            this.panel1.Controls.Add(this.btnChitiethoadon);
            this.panel1.Controls.Add(this.btnHoadon);
            this.panel1.Controls.Add(this.btnSanpham);
            this.panel1.Location = new System.Drawing.Point(1, 174);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(218, 578);
            this.panel1.TabIndex = 1;
            // 
            // btnNhacungcap
            // 
            this.btnNhacungcap.BorderRadius = 15;
            this.btnNhacungcap.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnNhacungcap.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnNhacungcap.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnNhacungcap.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnNhacungcap.FillColor = System.Drawing.Color.LightCoral;
            this.btnNhacungcap.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNhacungcap.ForeColor = System.Drawing.Color.White;
            this.btnNhacungcap.Image = global::DoAnCoSo.Properties.Resources.ncc2;
            this.btnNhacungcap.Location = new System.Drawing.Point(-31, 322);
            this.btnNhacungcap.Margin = new System.Windows.Forms.Padding(4);
            this.btnNhacungcap.Name = "btnNhacungcap";
            this.btnNhacungcap.Size = new System.Drawing.Size(213, 68);
            this.btnNhacungcap.TabIndex = 9;
            this.btnNhacungcap.Text = "Nhà cung cấp";
            this.btnNhacungcap.Click += new System.EventHandler(this.btnNhacungcap_Click);
            // 
            // btnThoat
            // 
            this.btnThoat.BorderRadius = 15;
            this.btnThoat.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnThoat.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnThoat.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnThoat.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnThoat.FillColor = System.Drawing.Color.LightCoral;
            this.btnThoat.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThoat.ForeColor = System.Drawing.Color.White;
            this.btnThoat.Image = global::DoAnCoSo.Properties.Resources.THOAT;
            this.btnThoat.Location = new System.Drawing.Point(-31, 474);
            this.btnThoat.Margin = new System.Windows.Forms.Padding(4);
            this.btnThoat.Name = "btnThoat";
            this.btnThoat.Size = new System.Drawing.Size(213, 68);
            this.btnThoat.TabIndex = 7;
            this.btnThoat.Text = "Thoát";
            this.btnThoat.Click += new System.EventHandler(this.btnThoat_Click);
            // 
            // btnTrangchu
            // 
            this.btnTrangchu.BorderRadius = 15;
            this.btnTrangchu.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnTrangchu.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnTrangchu.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnTrangchu.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnTrangchu.FillColor = System.Drawing.Color.LightCoral;
            this.btnTrangchu.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTrangchu.ForeColor = System.Drawing.Color.White;
            this.btnTrangchu.Image = global::DoAnCoSo.Properties.Resources.pngtree_home_vector_icon_png_image_5152511;
            this.btnTrangchu.ImageSize = new System.Drawing.Size(30, 30);
            this.btnTrangchu.Location = new System.Drawing.Point(-31, 18);
            this.btnTrangchu.Margin = new System.Windows.Forms.Padding(4);
            this.btnTrangchu.Name = "btnTrangchu";
            this.btnTrangchu.Size = new System.Drawing.Size(213, 68);
            this.btnTrangchu.TabIndex = 1;
            this.btnTrangchu.Text = "Trang chủ";
            // 
            // btnCaidat
            // 
            this.btnCaidat.BorderRadius = 15;
            this.btnCaidat.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnCaidat.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnCaidat.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnCaidat.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnCaidat.FillColor = System.Drawing.Color.LightCoral;
            this.btnCaidat.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCaidat.ForeColor = System.Drawing.Color.White;
            this.btnCaidat.Image = global::DoAnCoSo.Properties.Resources.caidat;
            this.btnCaidat.Location = new System.Drawing.Point(-31, 398);
            this.btnCaidat.Margin = new System.Windows.Forms.Padding(4);
            this.btnCaidat.Name = "btnCaidat";
            this.btnCaidat.Size = new System.Drawing.Size(213, 68);
            this.btnCaidat.TabIndex = 6;
            this.btnCaidat.Text = "Cài đặt";
            this.btnCaidat.Click += new System.EventHandler(this.btnCaidat_Click);
            // 
            // btnChitiethoadon
            // 
            this.btnChitiethoadon.BorderRadius = 15;
            this.btnChitiethoadon.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnChitiethoadon.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnChitiethoadon.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnChitiethoadon.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnChitiethoadon.FillColor = System.Drawing.Color.LightCoral;
            this.btnChitiethoadon.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnChitiethoadon.ForeColor = System.Drawing.Color.White;
            this.btnChitiethoadon.Image = global::DoAnCoSo.Properties.Resources.CHITIET;
            this.btnChitiethoadon.Location = new System.Drawing.Point(-31, 246);
            this.btnChitiethoadon.Margin = new System.Windows.Forms.Padding(4);
            this.btnChitiethoadon.Name = "btnChitiethoadon";
            this.btnChitiethoadon.Size = new System.Drawing.Size(213, 68);
            this.btnChitiethoadon.TabIndex = 5;
            this.btnChitiethoadon.Text = "Chi Tiết Hóa Đơn";
            this.btnChitiethoadon.Click += new System.EventHandler(this.btnChitiethoadon_Click);
            // 
            // btnHoadon
            // 
            this.btnHoadon.BorderRadius = 15;
            this.btnHoadon.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnHoadon.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnHoadon.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnHoadon.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnHoadon.FillColor = System.Drawing.Color.LightCoral;
            this.btnHoadon.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHoadon.ForeColor = System.Drawing.Color.White;
            this.btnHoadon.Image = global::DoAnCoSo.Properties.Resources.HD;
            this.btnHoadon.Location = new System.Drawing.Point(-31, 170);
            this.btnHoadon.Margin = new System.Windows.Forms.Padding(4);
            this.btnHoadon.Name = "btnHoadon";
            this.btnHoadon.Size = new System.Drawing.Size(213, 68);
            this.btnHoadon.TabIndex = 4;
            this.btnHoadon.Text = "Hóa đơn";
            this.btnHoadon.Click += new System.EventHandler(this.btnHoadon_Click);
            // 
            // btnSanpham
            // 
            this.btnSanpham.BorderRadius = 15;
            this.btnSanpham.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnSanpham.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnSanpham.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnSanpham.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnSanpham.FillColor = System.Drawing.Color.LightCoral;
            this.btnSanpham.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSanpham.ForeColor = System.Drawing.Color.White;
            this.btnSanpham.Image = global::DoAnCoSo.Properties.Resources.hop1;
            this.btnSanpham.ImageSize = new System.Drawing.Size(25, 25);
            this.btnSanpham.Location = new System.Drawing.Point(-31, 94);
            this.btnSanpham.Margin = new System.Windows.Forms.Padding(4);
            this.btnSanpham.Name = "btnSanpham";
            this.btnSanpham.Size = new System.Drawing.Size(213, 68);
            this.btnSanpham.TabIndex = 2;
            this.btnSanpham.Text = "Sản phẩm";
            this.btnSanpham.Click += new System.EventHandler(this.btnSanpham_Click);
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Times New Roman", 25.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(316, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(884, 60);
            this.label1.TabIndex = 2;
            this.label1.Text = "SHOP BÁN QUẦN ÁO THỜI TRANG NỮ";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // guna2PictureBox1
            // 
            this.guna2PictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("guna2PictureBox1.Image")));
            this.guna2PictureBox1.ImageRotate = 0F;
            this.guna2PictureBox1.Location = new System.Drawing.Point(341, 62);
            this.guna2PictureBox1.Name = "guna2PictureBox1";
            this.guna2PictureBox1.Size = new System.Drawing.Size(812, 624);
            this.guna2PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.guna2PictureBox1.TabIndex = 5;
            this.guna2PictureBox1.TabStop = false;
            // 
            // Trangchu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1454, 865);
            this.Controls.Add(this.guna2PictureBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Trangchu";
            this.Text = "Trang chủ";
            this.Load += new System.EventHandler(this.Trangchu_Load);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private Guna.UI2.WinForms.Guna2Button btnThoat;
        private Guna.UI2.WinForms.Guna2Button btnTrangchu;
        private Guna.UI2.WinForms.Guna2Button btnCaidat;
        private Guna.UI2.WinForms.Guna2Button btnChitiethoadon;
        private Guna.UI2.WinForms.Guna2Button btnHoadon;
        private Guna.UI2.WinForms.Guna2Button btnSanpham;
        private System.Windows.Forms.Label label1;
        private Guna.UI2.WinForms.Guna2Button btnNhacungcap;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox1;
    }
}
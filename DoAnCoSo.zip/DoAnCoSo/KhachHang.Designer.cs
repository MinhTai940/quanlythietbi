﻿namespace DoAnCoSo
{
    partial class Khachhang
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Khachhang));
            this.label8 = new System.Windows.Forms.Label();
            this.txtTimkiemkhachhang = new Guna.UI2.WinForms.Guna2TextBox();
            this.txtMakhachhang = new System.Windows.Forms.TextBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.btnQuaylaikh = new Guna.UI2.WinForms.Guna2Button();
            this.btnTailaikh = new Guna.UI2.WinForms.Guna2Button();
            this.btnSuakh = new Guna.UI2.WinForms.Guna2Button();
            this.btnXoakh = new Guna.UI2.WinForms.Guna2Button();
            this.btnThemkh = new Guna.UI2.WinForms.Guna2Button();
            this.btnTimkiemkh = new Guna.UI2.WinForms.Guna2ImageButton();
            this.txtTenkhachhang = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.guna2GroupBox1 = new Guna.UI2.WinForms.Guna2GroupBox();
            this.txtSdtkhachhang = new System.Windows.Forms.TextBox();
            this.txtDiachikhachhang = new System.Windows.Forms.TextBox();
            this.txtEmailkhachhang = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.dgvHienthithongtinkh = new System.Windows.Forms.DataGridView();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.guna2GroupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHienthithongtinkh)).BeginInit();
            this.SuspendLayout();
            // 
            // label8
            // 
            this.label8.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label8.Location = new System.Drawing.Point(531, 9);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(395, 61);
            this.label8.TabIndex = 51;
            this.label8.Text = "Quản lý khách hàng";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtTimkiemkhachhang
            // 
            this.txtTimkiemkhachhang.BorderRadius = 15;
            this.txtTimkiemkhachhang.BorderStyle = System.Drawing.Drawing2D.DashStyle.Custom;
            this.txtTimkiemkhachhang.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtTimkiemkhachhang.DefaultText = "";
            this.txtTimkiemkhachhang.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtTimkiemkhachhang.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtTimkiemkhachhang.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtTimkiemkhachhang.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtTimkiemkhachhang.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtTimkiemkhachhang.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtTimkiemkhachhang.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtTimkiemkhachhang.Location = new System.Drawing.Point(21, 36);
            this.txtTimkiemkhachhang.Name = "txtTimkiemkhachhang";
            this.txtTimkiemkhachhang.PasswordChar = '\0';
            this.txtTimkiemkhachhang.PlaceholderText = "";
            this.txtTimkiemkhachhang.SelectedText = "";
            this.txtTimkiemkhachhang.Size = new System.Drawing.Size(600, 54);
            this.txtTimkiemkhachhang.TabIndex = 11;
            // 
            // txtMakhachhang
            // 
            this.txtMakhachhang.Location = new System.Drawing.Point(177, 79);
            this.txtMakhachhang.Multiline = true;
            this.txtMakhachhang.Name = "txtMakhachhang";
            this.txtMakhachhang.Size = new System.Drawing.Size(350, 30);
            this.txtMakhachhang.TabIndex = 41;
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.Color.White;
            this.groupBox4.Controls.Add(this.btnQuaylaikh);
            this.groupBox4.Controls.Add(this.btnTailaikh);
            this.groupBox4.Controls.Add(this.btnSuakh);
            this.groupBox4.Controls.Add(this.btnXoakh);
            this.groupBox4.Controls.Add(this.btnThemkh);
            this.groupBox4.Location = new System.Drawing.Point(668, 196);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(712, 198);
            this.groupBox4.TabIndex = 43;
            this.groupBox4.TabStop = false;
            // 
            // btnQuaylaikh
            // 
            this.btnQuaylaikh.BorderRadius = 20;
            this.btnQuaylaikh.BorderThickness = 1;
            this.btnQuaylaikh.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnQuaylaikh.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnQuaylaikh.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnQuaylaikh.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnQuaylaikh.FillColor = System.Drawing.Color.LightCoral;
            this.btnQuaylaikh.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnQuaylaikh.ForeColor = System.Drawing.Color.White;
            this.btnQuaylaikh.HoverState.BorderColor = System.Drawing.Color.LightCoral;
            this.btnQuaylaikh.HoverState.FillColor = System.Drawing.Color.White;
            this.btnQuaylaikh.HoverState.ForeColor = System.Drawing.Color.LightCoral;
            this.btnQuaylaikh.Location = new System.Drawing.Point(491, 104);
            this.btnQuaylaikh.Name = "btnQuaylaikh";
            this.btnQuaylaikh.Size = new System.Drawing.Size(200, 60);
            this.btnQuaylaikh.TabIndex = 42;
            this.btnQuaylaikh.Text = "Quay lại";
            this.btnQuaylaikh.Click += new System.EventHandler(this.btnQuaylaikh_Click);
            // 
            // btnTailaikh
            // 
            this.btnTailaikh.BorderRadius = 20;
            this.btnTailaikh.BorderThickness = 1;
            this.btnTailaikh.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnTailaikh.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnTailaikh.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnTailaikh.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnTailaikh.FillColor = System.Drawing.Color.LightCoral;
            this.btnTailaikh.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTailaikh.ForeColor = System.Drawing.Color.White;
            this.btnTailaikh.HoverState.BorderColor = System.Drawing.Color.LightCoral;
            this.btnTailaikh.HoverState.FillColor = System.Drawing.Color.White;
            this.btnTailaikh.HoverState.ForeColor = System.Drawing.Color.LightCoral;
            this.btnTailaikh.Location = new System.Drawing.Point(265, 104);
            this.btnTailaikh.Name = "btnTailaikh";
            this.btnTailaikh.Size = new System.Drawing.Size(200, 60);
            this.btnTailaikh.TabIndex = 39;
            this.btnTailaikh.Text = "Tải lại";
            this.btnTailaikh.Click += new System.EventHandler(this.btnTailaikh_Click);
            // 
            // btnSuakh
            // 
            this.btnSuakh.BorderRadius = 20;
            this.btnSuakh.BorderThickness = 1;
            this.btnSuakh.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnSuakh.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnSuakh.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnSuakh.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnSuakh.FillColor = System.Drawing.Color.LightCoral;
            this.btnSuakh.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSuakh.ForeColor = System.Drawing.Color.White;
            this.btnSuakh.HoverState.BorderColor = System.Drawing.Color.LightCoral;
            this.btnSuakh.HoverState.FillColor = System.Drawing.Color.White;
            this.btnSuakh.HoverState.ForeColor = System.Drawing.Color.LightCoral;
            this.btnSuakh.Location = new System.Drawing.Point(30, 104);
            this.btnSuakh.Name = "btnSuakh";
            this.btnSuakh.Size = new System.Drawing.Size(200, 60);
            this.btnSuakh.TabIndex = 40;
            this.btnSuakh.Text = "Sửa khách hàng";
            this.btnSuakh.Click += new System.EventHandler(this.btnSuakh_Click);
            // 
            // btnXoakh
            // 
            this.btnXoakh.BorderRadius = 20;
            this.btnXoakh.BorderThickness = 1;
            this.btnXoakh.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnXoakh.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnXoakh.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnXoakh.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnXoakh.FillColor = System.Drawing.Color.LightCoral;
            this.btnXoakh.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXoakh.ForeColor = System.Drawing.Color.White;
            this.btnXoakh.HoverState.BorderColor = System.Drawing.Color.LightCoral;
            this.btnXoakh.HoverState.FillColor = System.Drawing.Color.White;
            this.btnXoakh.HoverState.ForeColor = System.Drawing.Color.LightCoral;
            this.btnXoakh.Location = new System.Drawing.Point(265, 29);
            this.btnXoakh.Name = "btnXoakh";
            this.btnXoakh.Size = new System.Drawing.Size(200, 60);
            this.btnXoakh.TabIndex = 38;
            this.btnXoakh.Text = "Xóa khách hàng";
            this.btnXoakh.Click += new System.EventHandler(this.btnXoakh_Click);
            // 
            // btnThemkh
            // 
            this.btnThemkh.BorderRadius = 20;
            this.btnThemkh.BorderThickness = 1;
            this.btnThemkh.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnThemkh.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnThemkh.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnThemkh.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnThemkh.FillColor = System.Drawing.Color.LightCoral;
            this.btnThemkh.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThemkh.ForeColor = System.Drawing.Color.White;
            this.btnThemkh.HoverState.BorderColor = System.Drawing.Color.LightCoral;
            this.btnThemkh.HoverState.FillColor = System.Drawing.Color.White;
            this.btnThemkh.HoverState.ForeColor = System.Drawing.Color.LightCoral;
            this.btnThemkh.Location = new System.Drawing.Point(30, 26);
            this.btnThemkh.Name = "btnThemkh";
            this.btnThemkh.Size = new System.Drawing.Size(200, 60);
            this.btnThemkh.TabIndex = 37;
            this.btnThemkh.Text = "Thêm khách hàng";
            this.btnThemkh.Click += new System.EventHandler(this.btnThemkh_Click);
            // 
            // btnTimkiemkh
            // 
            this.btnTimkiemkh.CheckedState.ImageSize = new System.Drawing.Size(64, 64);
            this.btnTimkiemkh.HoverState.ImageSize = new System.Drawing.Size(64, 64);
            this.btnTimkiemkh.Image = ((System.Drawing.Image)(resources.GetObject("btnTimkiemkh.Image")));
            this.btnTimkiemkh.ImageOffset = new System.Drawing.Point(0, 0);
            this.btnTimkiemkh.ImageRotate = 0F;
            this.btnTimkiemkh.Location = new System.Drawing.Point(627, 36);
            this.btnTimkiemkh.Name = "btnTimkiemkh";
            this.btnTimkiemkh.PressedState.ImageSize = new System.Drawing.Size(64, 64);
            this.btnTimkiemkh.Size = new System.Drawing.Size(64, 54);
            this.btnTimkiemkh.TabIndex = 12;
            this.btnTimkiemkh.Click += new System.EventHandler(this.btnTimkiemkh_Click);
            // 
            // txtTenkhachhang
            // 
            this.txtTenkhachhang.Location = new System.Drawing.Point(177, 142);
            this.txtTenkhachhang.Multiline = true;
            this.txtTenkhachhang.Name = "txtTenkhachhang";
            this.txtTenkhachhang.Size = new System.Drawing.Size(350, 30);
            this.txtTenkhachhang.TabIndex = 40;
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.Color.White;
            this.groupBox3.Controls.Add(this.btnTimkiemkh);
            this.groupBox3.Controls.Add(this.txtTimkiemkhachhang);
            this.groupBox3.Location = new System.Drawing.Point(668, 57);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(712, 127);
            this.groupBox3.TabIndex = 42;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Tìm kiếm";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(33, 86);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(119, 19);
            this.label1.TabIndex = 32;
            this.label1.Text = "Mã khách hàng";
            // 
            // guna2GroupBox1
            // 
            this.guna2GroupBox1.Controls.Add(this.txtMakhachhang);
            this.guna2GroupBox1.Controls.Add(this.groupBox4);
            this.guna2GroupBox1.Controls.Add(this.txtTenkhachhang);
            this.guna2GroupBox1.Controls.Add(this.groupBox3);
            this.guna2GroupBox1.Controls.Add(this.txtSdtkhachhang);
            this.guna2GroupBox1.Controls.Add(this.txtDiachikhachhang);
            this.guna2GroupBox1.Controls.Add(this.txtEmailkhachhang);
            this.guna2GroupBox1.Controls.Add(this.label5);
            this.guna2GroupBox1.Controls.Add(this.label4);
            this.guna2GroupBox1.Controls.Add(this.label3);
            this.guna2GroupBox1.Controls.Add(this.label2);
            this.guna2GroupBox1.Controls.Add(this.label1);
            this.guna2GroupBox1.CustomBorderColor = System.Drawing.Color.LightCoral;
            this.guna2GroupBox1.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.guna2GroupBox1.ForeColor = System.Drawing.Color.White;
            this.guna2GroupBox1.Location = new System.Drawing.Point(12, 86);
            this.guna2GroupBox1.Name = "guna2GroupBox1";
            this.guna2GroupBox1.Size = new System.Drawing.Size(1412, 420);
            this.guna2GroupBox1.TabIndex = 50;
            this.guna2GroupBox1.Text = "Thông Tin Khách Hàng";
            // 
            // txtSdtkhachhang
            // 
            this.txtSdtkhachhang.Location = new System.Drawing.Point(177, 263);
            this.txtSdtkhachhang.Multiline = true;
            this.txtSdtkhachhang.Name = "txtSdtkhachhang";
            this.txtSdtkhachhang.Size = new System.Drawing.Size(350, 30);
            this.txtSdtkhachhang.TabIndex = 39;
            // 
            // txtDiachikhachhang
            // 
            this.txtDiachikhachhang.Location = new System.Drawing.Point(177, 196);
            this.txtDiachikhachhang.Multiline = true;
            this.txtDiachikhachhang.Name = "txtDiachikhachhang";
            this.txtDiachikhachhang.Size = new System.Drawing.Size(350, 30);
            this.txtDiachikhachhang.TabIndex = 38;
            // 
            // txtEmailkhachhang
            // 
            this.txtEmailkhachhang.Location = new System.Drawing.Point(177, 330);
            this.txtEmailkhachhang.Multiline = true;
            this.txtEmailkhachhang.Name = "txtEmailkhachhang";
            this.txtEmailkhachhang.Size = new System.Drawing.Size(350, 30);
            this.txtEmailkhachhang.TabIndex = 37;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(33, 145);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(122, 19);
            this.label5.TabIndex = 36;
            this.label5.Text = "Tên khách hàng";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(33, 199);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(66, 19);
            this.label4.TabIndex = 35;
            this.label4.Text = "Địa chỉ ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(33, 266);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(105, 19);
            this.label3.TabIndex = 34;
            this.label3.Text = "Số điện thoại";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(33, 333);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(54, 19);
            this.label2.TabIndex = 33;
            this.label2.Text = "Email";
            // 
            // dgvHienthithongtinkh
            // 
            this.dgvHienthithongtinkh.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvHienthithongtinkh.Location = new System.Drawing.Point(12, 536);
            this.dgvHienthithongtinkh.Name = "dgvHienthithongtinkh";
            this.dgvHienthithongtinkh.RowHeadersWidth = 51;
            this.dgvHienthithongtinkh.RowTemplate.Height = 24;
            this.dgvHienthithongtinkh.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvHienthithongtinkh.Size = new System.Drawing.Size(1412, 289);
            this.dgvHienthithongtinkh.TabIndex = 49;
            this.dgvHienthithongtinkh.SelectionChanged += new System.EventHandler(this.dgvHienthithongtinkh_SelectionChanged);
            // 
            // Khachhang
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1436, 818);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.guna2GroupBox1);
            this.Controls.Add(this.dgvHienthithongtinkh);
            this.Name = "Khachhang";
            this.Text = "Khách hàng";
            this.groupBox4.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.guna2GroupBox1.ResumeLayout(false);
            this.guna2GroupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHienthithongtinkh)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label8;
        private Guna.UI2.WinForms.Guna2TextBox txtTimkiemkhachhang;
        private System.Windows.Forms.TextBox txtMakhachhang;
        private System.Windows.Forms.GroupBox groupBox4;
        private Guna.UI2.WinForms.Guna2Button btnQuaylaikh;
        private Guna.UI2.WinForms.Guna2Button btnTailaikh;
        private Guna.UI2.WinForms.Guna2Button btnSuakh;
        private Guna.UI2.WinForms.Guna2Button btnXoakh;
        private Guna.UI2.WinForms.Guna2Button btnThemkh;
        private Guna.UI2.WinForms.Guna2ImageButton btnTimkiemkh;
        private System.Windows.Forms.TextBox txtTenkhachhang;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label1;
        private Guna.UI2.WinForms.Guna2GroupBox guna2GroupBox1;
        private System.Windows.Forms.TextBox txtSdtkhachhang;
        private System.Windows.Forms.TextBox txtDiachikhachhang;
        private System.Windows.Forms.TextBox txtEmailkhachhang;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridView dgvHienthithongtinkh;
    }
}
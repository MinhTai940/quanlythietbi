﻿namespace DoAnCoSo
{
    partial class DanhMucSanPham
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.guna2GroupBox1 = new Guna.UI2.WinForms.Guna2GroupBox();
            this.txtMotadanhmuc = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtMadanhmuc = new System.Windows.Forms.TextBox();
            this.txtTendanhmuc = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnSuadm = new Guna.UI2.WinForms.Guna2Button();
            this.dgvDanhMucSanPham = new System.Windows.Forms.DataGridView();
            this.btnXoadm = new Guna.UI2.WinForms.Guna2Button();
            this.btnThemdm = new Guna.UI2.WinForms.Guna2Button();
            this.label4 = new System.Windows.Forms.Label();
            this.guna2GroupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDanhMucSanPham)).BeginInit();
            this.SuspendLayout();
            // 
            // guna2GroupBox1
            // 
            this.guna2GroupBox1.Controls.Add(this.txtMotadanhmuc);
            this.guna2GroupBox1.Controls.Add(this.label9);
            this.guna2GroupBox1.Controls.Add(this.txtMadanhmuc);
            this.guna2GroupBox1.Controls.Add(this.txtTendanhmuc);
            this.guna2GroupBox1.Controls.Add(this.label5);
            this.guna2GroupBox1.Controls.Add(this.label1);
            this.guna2GroupBox1.CustomBorderColor = System.Drawing.Color.LightCoral;
            this.guna2GroupBox1.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.guna2GroupBox1.ForeColor = System.Drawing.Color.White;
            this.guna2GroupBox1.Location = new System.Drawing.Point(12, 73);
            this.guna2GroupBox1.Name = "guna2GroupBox1";
            this.guna2GroupBox1.Size = new System.Drawing.Size(1412, 314);
            this.guna2GroupBox1.TabIndex = 45;
            this.guna2GroupBox1.Text = "Thông Tin Danh Mục Sản Phẩm";
            // 
            // txtMotadanhmuc
            // 
            this.txtMotadanhmuc.Location = new System.Drawing.Point(627, 141);
            this.txtMotadanhmuc.Multiline = true;
            this.txtMotadanhmuc.Name = "txtMotadanhmuc";
            this.txtMotadanhmuc.Size = new System.Drawing.Size(350, 30);
            this.txtMotadanhmuc.TabIndex = 25;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(432, 221);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(110, 19);
            this.label9.TabIndex = 28;
            this.label9.Text = "Tên danh mục";
            // 
            // txtMadanhmuc
            // 
            this.txtMadanhmuc.Location = new System.Drawing.Point(627, 75);
            this.txtMadanhmuc.Multiline = true;
            this.txtMadanhmuc.Name = "txtMadanhmuc";
            this.txtMadanhmuc.Size = new System.Drawing.Size(350, 30);
            this.txtMadanhmuc.TabIndex = 23;
            // 
            // txtTendanhmuc
            // 
            this.txtTendanhmuc.Location = new System.Drawing.Point(627, 218);
            this.txtTendanhmuc.Multiline = true;
            this.txtTendanhmuc.Name = "txtTendanhmuc";
            this.txtTendanhmuc.Size = new System.Drawing.Size(350, 30);
            this.txtTendanhmuc.TabIndex = 24;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(435, 144);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(52, 19);
            this.label5.TabIndex = 27;
            this.label5.Text = "Mô tả";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(435, 78);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(107, 19);
            this.label1.TabIndex = 26;
            this.label1.Text = "Mã danh mục";
            // 
            // btnSuadm
            // 
            this.btnSuadm.BorderRadius = 20;
            this.btnSuadm.BorderThickness = 1;
            this.btnSuadm.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnSuadm.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnSuadm.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnSuadm.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnSuadm.FillColor = System.Drawing.Color.LightCoral;
            this.btnSuadm.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSuadm.ForeColor = System.Drawing.Color.White;
            this.btnSuadm.HoverState.BorderColor = System.Drawing.Color.LightCoral;
            this.btnSuadm.HoverState.FillColor = System.Drawing.Color.White;
            this.btnSuadm.HoverState.ForeColor = System.Drawing.Color.LightCoral;
            this.btnSuadm.Location = new System.Drawing.Point(1033, 429);
            this.btnSuadm.Name = "btnSuadm";
            this.btnSuadm.Size = new System.Drawing.Size(200, 60);
            this.btnSuadm.TabIndex = 47;
            this.btnSuadm.Text = "Sửa danh mục";
            this.btnSuadm.Click += new System.EventHandler(this.btnSuadm_Click);
            // 
            // dgvDanhMucSanPham
            // 
            this.dgvDanhMucSanPham.BackgroundColor = System.Drawing.Color.White;
            this.dgvDanhMucSanPham.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDanhMucSanPham.Location = new System.Drawing.Point(12, 517);
            this.dgvDanhMucSanPham.Name = "dgvDanhMucSanPham";
            this.dgvDanhMucSanPham.RowHeadersWidth = 51;
            this.dgvDanhMucSanPham.RowTemplate.Height = 24;
            this.dgvDanhMucSanPham.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvDanhMucSanPham.Size = new System.Drawing.Size(1412, 289);
            this.dgvDanhMucSanPham.TabIndex = 44;
            this.dgvDanhMucSanPham.SelectionChanged += new System.EventHandler(this.dgvDanhMucSanPham_SelectionChanged);
            // 
            // btnXoadm
            // 
            this.btnXoadm.BorderRadius = 20;
            this.btnXoadm.BorderThickness = 1;
            this.btnXoadm.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnXoadm.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnXoadm.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnXoadm.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnXoadm.FillColor = System.Drawing.Color.LightCoral;
            this.btnXoadm.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXoadm.ForeColor = System.Drawing.Color.White;
            this.btnXoadm.HoverState.BorderColor = System.Drawing.Color.LightCoral;
            this.btnXoadm.HoverState.FillColor = System.Drawing.Color.White;
            this.btnXoadm.HoverState.ForeColor = System.Drawing.Color.LightCoral;
            this.btnXoadm.Location = new System.Drawing.Point(648, 429);
            this.btnXoadm.Name = "btnXoadm";
            this.btnXoadm.Size = new System.Drawing.Size(200, 60);
            this.btnXoadm.TabIndex = 48;
            this.btnXoadm.Text = "Xóa danh mục";
            this.btnXoadm.Click += new System.EventHandler(this.btnXoadm_Click);
            // 
            // btnThemdm
            // 
            this.btnThemdm.BorderRadius = 20;
            this.btnThemdm.BorderThickness = 1;
            this.btnThemdm.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnThemdm.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnThemdm.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnThemdm.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnThemdm.FillColor = System.Drawing.Color.LightCoral;
            this.btnThemdm.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThemdm.ForeColor = System.Drawing.Color.White;
            this.btnThemdm.HoverState.BorderColor = System.Drawing.Color.LightCoral;
            this.btnThemdm.HoverState.FillColor = System.Drawing.Color.White;
            this.btnThemdm.HoverState.ForeColor = System.Drawing.Color.LightCoral;
            this.btnThemdm.Location = new System.Drawing.Point(196, 429);
            this.btnThemdm.Name = "btnThemdm";
            this.btnThemdm.Size = new System.Drawing.Size(200, 60);
            this.btnThemdm.TabIndex = 49;
            this.btnThemdm.Text = "Thêm danh mục";
            this.btnThemdm.Click += new System.EventHandler(this.btnThemdm_Click);
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label4.Location = new System.Drawing.Point(434, 9);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(497, 61);
            this.label4.TabIndex = 50;
            this.label4.Text = "Quản Lý Danh Mục Sản Phẩm";
            // 
            // DanhMucSanPham
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1436, 818);
            this.Controls.Add(this.guna2GroupBox1);
            this.Controls.Add(this.btnSuadm);
            this.Controls.Add(this.dgvDanhMucSanPham);
            this.Controls.Add(this.btnXoadm);
            this.Controls.Add(this.btnThemdm);
            this.Controls.Add(this.label4);
            this.Name = "DanhMucSanPham";
            this.Text = "DanhMucSanPham";
            this.guna2GroupBox1.ResumeLayout(false);
            this.guna2GroupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDanhMucSanPham)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private Guna.UI2.WinForms.Guna2GroupBox guna2GroupBox1;
        private System.Windows.Forms.TextBox txtMotadanhmuc;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtMadanhmuc;
        private System.Windows.Forms.TextBox txtTendanhmuc;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label1;
        private Guna.UI2.WinForms.Guna2Button btnSuadm;
        private System.Windows.Forms.DataGridView dgvDanhMucSanPham;
        private Guna.UI2.WinForms.Guna2Button btnXoadm;
        private Guna.UI2.WinForms.Guna2Button btnThemdm;
        private System.Windows.Forms.Label label4;
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DoAnCoSo
{
    public partial class Hoadon : Form
    {
        string connectionString = "Data Source=DESKTOP-DL8SVNN\\PHUONGANH;Initial Catalog=QuanLyThoiTrangNu;User ID=sa;Password=12345678;Integrated Security=True";
        public Hoadon()
        {
            InitializeComponent();
            Hienthithonghoadon();
            LoadManhanvien();
            LoadMakhachhang();
            ClearFormHoadon();
        }
        private void Hienthithonghoadon()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT * FROM Hoa_Don";

                    using (SqlDataAdapter adapter = new SqlDataAdapter(query, connection))
                    {
                        DataSet dataSet = new DataSet();
                        adapter.Fill(dataSet);
                        dgvHoadon.DataSource = dataSet.Tables[0];
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi hiển thị danh sách hóa đơn: " + ex.Message);
            }
        }

        private void dgvHoadon_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvHoadon.SelectedRows.Count == 0) return;

            DataGridViewRow row = dgvHoadon.SelectedRows[0];

            cmbMakhachhang.SelectedValue = Convert.ToInt32(row.Cells["Ma_Khach_Hang"].Value?.ToString());
            cmbManhanvien.SelectedValue = Convert.ToInt32(row.Cells["Ma_Nhan_Vien"].Value?.ToString());
            txtMahoadon.Text = row.Cells["Ma_Hoa_Don"].Value?.ToString();
            txtTongtien.Text = row.Cells["Tong_Tien"].Value?.ToString();
            if (DateTime.TryParse(row.Cells["Ngay_Lap"].Value?.ToString(), out DateTime ngayLap))
                dtpNgaylaphd.Value = ngayLap;

            txtMahoadon.ReadOnly = true;
        }
        private void LoadManhanvien()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT DISTINCT Ma_Nhan_Vien FROM Nhan_Vien";
                    using (SqlDataAdapter adapter = new SqlDataAdapter(query, connection))
                    {
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);
                        cmbManhanvien.DataSource = dt;
                        cmbManhanvien.DisplayMember = "Ma_Nhan_Vien";
                        cmbManhanvien.ValueMember = "Ma_Nhan_Vien";

                        cmbManhanvien.SelectedIndex = -1;
                    }    
                }    
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi khi tải mã nhân viên: {ex.Message}", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void LoadMakhachhang()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT DISTINCT Ma_Khach_Hang FROM Khach_Hang";
                    using (SqlDataAdapter adapter = new SqlDataAdapter(query, connection))
                    {
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);

                        cmbMakhachhang.DataSource = dt;
                        cmbMakhachhang.DisplayMember = "Ma_Khach_Hang";
                        cmbMakhachhang.ValueMember = "Ma_Khach_Hang";

                        cmbMakhachhang.SelectedIndex = -1;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi khi tải mã nhân viên: {ex.Message}", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void btnThemhd_Click(object sender, EventArgs e)
        {
            try
            {
                string maHoaDon = txtMahoadon.Text.Trim();
                int maNhanVien = Convert.ToInt32(cmbManhanvien.SelectedValue.ToString());
                int maKhachHang = Convert.ToInt32(cmbMakhachhang.SelectedValue.ToString());
                decimal tongTien = Convert.ToDecimal(txtTongtien.Text.Trim());
                DateTime ngayLap = dtpNgaylaphd.Value;

                if (string.IsNullOrEmpty(maHoaDon) || cmbManhanvien.SelectedIndex == -1 || cmbMakhachhang.SelectedIndex == -1 || string.IsNullOrEmpty(txtTongtien.Text))
                {
                    MessageBox.Show("Vui lòng nhập đầy đủ thông tin bắt buộc!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    string checkQuery = "SELECT COUNT(*) FROM Hoa_Don WHERE Ma_Hoa_Don = @Ma_Hoa_Don";
                    using (SqlCommand checkCommand = new SqlCommand(checkQuery, connection))
                    {
                        checkCommand.Parameters.AddWithValue("@Ma_Hoa_Don", maHoaDon);
                        int count = (int)checkCommand.ExecuteScalar();
                        if (count > 0)
                        {
                            MessageBox.Show("Mã hóa đơn đã tồn tại! Vui lòng nhập mã khác.");
                            return;
                        }
                    }

                    string query = "INSERT INTO Hoa_Don (Ma_Hoa_Don, Ma_Khach_Hang, Ma_Nhan_Vien, Ngay_Lap, Tong_Tien) " +
                                    "VALUES (@Ma_Hoa_Don, @Ma_Khach_Hang, @Ma_Nhan_Vien, @Ngay_Lap, @Tong_Tien)";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@Ma_Hoa_Don", maHoaDon);
                        command.Parameters.AddWithValue("@Ma_Khach_Hang", maKhachHang);
                        command.Parameters.AddWithValue("@Ma_Nhan_Vien", maNhanVien);
                        command.Parameters.AddWithValue("@Ngay_Lap", ngayLap);
                        command.Parameters.AddWithValue("@Tong_Tien", tongTien);
                        command.ExecuteNonQuery();
                    }
                    MessageBox.Show("Thêm hóa đơn thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Hienthithonghoadon();
                    ClearFormHoadon();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi thêm hóa đơn: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void ClearFormHoadon()
        {
            txtMahoadon.Text = "";
            cmbMakhachhang.SelectedIndex = -1;
            cmbManhanvien.SelectedIndex = -1;
            DateTime ngayLap = dtpNgaylaphd.Value;
            txtTongtien.Text = "";
            txtMahoadon.ReadOnly = false;
        }
    }
}

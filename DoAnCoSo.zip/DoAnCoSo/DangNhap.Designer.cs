﻿namespace DoAnCoSo
{
    partial class Dangnhap
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Dangnhap));
            this.btnDangnhap = new Guna.UI2.WinForms.Guna2Button();
            this.label2 = new System.Windows.Forms.Label();
            this.btnTailai = new Guna.UI2.WinForms.Guna2Button();
            this.btnThoat = new Guna.UI2.WinForms.Guna2ImageButton();
            this.guna2PictureBox1 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.txtDangnhaptk = new Guna.UI2.WinForms.Guna2TextBox();
            this.txtMatkhau = new Guna.UI2.WinForms.Guna2TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // btnDangnhap
            // 
            this.btnDangnhap.BorderRadius = 18;
            this.btnDangnhap.BorderThickness = 1;
            this.btnDangnhap.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnDangnhap.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnDangnhap.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnDangnhap.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnDangnhap.FillColor = System.Drawing.Color.Lime;
            this.btnDangnhap.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnDangnhap.ForeColor = System.Drawing.Color.White;
            this.btnDangnhap.HoverState.BorderColor = System.Drawing.Color.Lime;
            this.btnDangnhap.HoverState.FillColor = System.Drawing.Color.White;
            this.btnDangnhap.HoverState.ForeColor = System.Drawing.Color.Lime;
            this.btnDangnhap.Image = global::DoAnCoSo.Properties.Resources.sinhvien;
            this.btnDangnhap.Location = new System.Drawing.Point(366, 568);
            this.btnDangnhap.Name = "btnDangnhap";
            this.btnDangnhap.Size = new System.Drawing.Size(204, 45);
            this.btnDangnhap.TabIndex = 5;
            this.btnDangnhap.Text = "Đăng nhập";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.label2.Location = new System.Drawing.Point(37, 659);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(409, 18);
            this.label2.TabIndex = 7;
            this.label2.Text = "*Bạn sẽ chấp nhận các điều khoản và điều kiện của chúng tôi";
            // 
            // btnTailai
            // 
            this.btnTailai.BorderRadius = 18;
            this.btnTailai.BorderThickness = 1;
            this.btnTailai.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnTailai.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnTailai.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnTailai.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnTailai.FillColor = System.Drawing.Color.Lime;
            this.btnTailai.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnTailai.ForeColor = System.Drawing.Color.White;
            this.btnTailai.HoverState.BorderColor = System.Drawing.Color.Lime;
            this.btnTailai.HoverState.FillColor = System.Drawing.Color.White;
            this.btnTailai.HoverState.ForeColor = System.Drawing.Color.Lime;
            this.btnTailai.Image = global::DoAnCoSo.Properties.Resources.tailai;
            this.btnTailai.Location = new System.Drawing.Point(577, 568);
            this.btnTailai.Name = "btnTailai";
            this.btnTailai.Size = new System.Drawing.Size(204, 45);
            this.btnTailai.TabIndex = 11;
            this.btnTailai.Text = "Tải lại";
            // 
            // btnThoat
            // 
            this.btnThoat.CheckedState.ImageSize = new System.Drawing.Size(64, 64);
            this.btnThoat.HoverState.ImageSize = new System.Drawing.Size(64, 64);
            this.btnThoat.Image = ((System.Drawing.Image)(resources.GetObject("btnThoat.Image")));
            this.btnThoat.ImageOffset = new System.Drawing.Point(0, 0);
            this.btnThoat.ImageRotate = 0F;
            this.btnThoat.Location = new System.Drawing.Point(1067, 3);
            this.btnThoat.Name = "btnThoat";
            this.btnThoat.PressedState.ImageSize = new System.Drawing.Size(64, 64);
            this.btnThoat.Size = new System.Drawing.Size(29, 34);
            this.btnThoat.TabIndex = 9;
            this.btnThoat.Click += new System.EventHandler(this.btnThoat_Click);
            // 
            // guna2PictureBox1
            // 
            this.guna2PictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("guna2PictureBox1.Image")));
            this.guna2PictureBox1.ImageRotate = 0F;
            this.guna2PictureBox1.Location = new System.Drawing.Point(465, 106);
            this.guna2PictureBox1.Name = "guna2PictureBox1";
            this.guna2PictureBox1.Size = new System.Drawing.Size(225, 225);
            this.guna2PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.guna2PictureBox1.TabIndex = 1;
            this.guna2PictureBox1.TabStop = false;
            // 
            // txtDangnhaptk
            // 
            this.txtDangnhaptk.BorderRadius = 18;
            this.txtDangnhaptk.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtDangnhaptk.DefaultText = "";
            this.txtDangnhaptk.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtDangnhaptk.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtDangnhaptk.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtDangnhaptk.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtDangnhaptk.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtDangnhaptk.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtDangnhaptk.ForeColor = System.Drawing.Color.Black;
            this.txtDangnhaptk.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtDangnhaptk.IconLeft = ((System.Drawing.Image)(resources.GetObject("txtDangnhaptk.IconLeft")));
            this.txtDangnhaptk.IconLeftSize = new System.Drawing.Size(50, 50);
            this.txtDangnhaptk.Location = new System.Drawing.Point(366, 358);
            this.txtDangnhaptk.Name = "txtDangnhaptk";
            this.txtDangnhaptk.PasswordChar = '\0';
            this.txtDangnhaptk.PlaceholderText = "Đăng Nhập Tài Khoản";
            this.txtDangnhaptk.SelectedText = "";
            this.txtDangnhaptk.Size = new System.Drawing.Size(415, 67);
            this.txtDangnhaptk.TabIndex = 3;
            // 
            // txtMatkhau
            // 
            this.txtMatkhau.BorderRadius = 18;
            this.txtMatkhau.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtMatkhau.DefaultText = "";
            this.txtMatkhau.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtMatkhau.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtMatkhau.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtMatkhau.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtMatkhau.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtMatkhau.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtMatkhau.ForeColor = System.Drawing.Color.Black;
            this.txtMatkhau.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtMatkhau.IconLeft = ((System.Drawing.Image)(resources.GetObject("txtMatkhau.IconLeft")));
            this.txtMatkhau.IconLeftSize = new System.Drawing.Size(50, 50);
            this.txtMatkhau.IconRight = ((System.Drawing.Image)(resources.GetObject("txtMatkhau.IconRight")));
            this.txtMatkhau.IconRightSize = new System.Drawing.Size(30, 30);
            this.txtMatkhau.Location = new System.Drawing.Point(366, 459);
            this.txtMatkhau.Name = "txtMatkhau";
            this.txtMatkhau.PasswordChar = '\0';
            this.txtMatkhau.PlaceholderText = "Mật Khẩu";
            this.txtMatkhau.SelectedText = "";
            this.txtMatkhau.Size = new System.Drawing.Size(415, 67);
            this.txtMatkhau.TabIndex = 4;
            // 
            // Dangnhap
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1099, 713);
            this.Controls.Add(this.btnTailai);
            this.Controls.Add(this.btnThoat);
            this.Controls.Add(this.guna2PictureBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtDangnhaptk);
            this.Controls.Add(this.txtMatkhau);
            this.Controls.Add(this.btnDangnhap);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Dangnhap";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Đăng nhập";
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox1;
        private Guna.UI2.WinForms.Guna2TextBox txtDangnhaptk;
        private Guna.UI2.WinForms.Guna2TextBox txtMatkhau;
        private Guna.UI2.WinForms.Guna2Button btnDangnhap;
        private System.Windows.Forms.Label label2;
        private Guna.UI2.WinForms.Guna2ImageButton btnThoat;
        private Guna.UI2.WinForms.Guna2Button btnTailai;
    }
}


﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.UI.WebControls;
using System.Windows.Forms;
using TheArtOfDevHtmlRenderer.Adapters;

namespace DoAnCoSo
{
    public partial class Khachhang : Form
    {
        string connectionString = "Data Source=DESKTOP-DL8SVNN\\PHUONGANH;Initial Catalog=QuanLyThoiTrangNu;User ID=sa;Password=12345678;Integrated Security=True";
        public Khachhang()
        {
            InitializeComponent();
            Hienthithongkhachhang();
        }

        private void Hienthithongkhachhang()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT * FROM Khach_Hang";

                    using (SqlDataAdapter adapter = new SqlDataAdapter(query,connection))
                    {
                        DataSet dataSet = new DataSet();
                        adapter.Fill(dataSet);
                        dgvHienthithongtinkh.DataSource = dataSet.Tables[0];
                    }    
    
                }      
            }
            catch(Exception ex)
            {
                MessageBox.Show("Lỗi khi hiển thị danh sách khách hàng: " + ex.Message);
            }
        }

        private void btnThemkh_Click(object sender, EventArgs e)
        {
            try
            {
                string maKhachHang = txtMakhachhang.Text.Trim();
                string tenKhachHang = txtTenkhachhang.Text.Trim();
                string diaChi = txtDiachikhachhang.Text.Trim();
                string soDienThoai = txtSdtkhachhang.Text.Trim();
                string email = txtEmailkhachhang.Text.Trim();
             
                if(string.IsNullOrEmpty(maKhachHang) || string.IsNullOrEmpty(tenKhachHang) || string.IsNullOrEmpty(diaChi) || string.IsNullOrEmpty(soDienThoai) || string.IsNullOrEmpty(email))
                {
                    MessageBox.Show("Vui lòng nhập đầy đủ thông tin bắt buộc!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // Kiểm tra định dạng số điện thoại: chỉ chứa số và độ dài từ 9-11
                if (!System.Text.RegularExpressions.Regex.IsMatch(soDienThoai, @"^\d{9,11}$"))
                {
                    MessageBox.Show("Số điện thoại không hợp lệ! Vui lòng nhập 9-11 chữ số.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // Kiểm tra định dạng email
                if (!System.Text.RegularExpressions.Regex.IsMatch(email, @"^[^@\s]+@[^@\s]+\.[^@\s]+$"))
                {
                    MessageBox.Show("Email không hợp lệ! Vui lòng nhập đúng định dạng (vd: ten@gmail.com).", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    string checkQuery = "SELECT COUNT(*) FROM Khach_Hang WHERE Ma_Khach_Hang = @Ma_Khach_Hang";
                    using (SqlCommand checkCommand = new SqlCommand(checkQuery, connection))
                    {
                        checkCommand.Parameters.AddWithValue("@Ma_Khach_Hang", maKhachHang);
                        int count = (int)checkCommand.ExecuteScalar();
                        if(count > 0)
                        {
                            MessageBox.Show("Mã khách hàng đã tồn tại! Vui lòng nhập mã khác.");
                            return;
                        }    
                    }

                    string query = "INSERT INTO Khach_Hang (Ma_Khach_Hang, Ho_Ten, Dia_Chi, So_Dien_Thoai, Email) " +
                                    "VALUES (@Ma_Khach_Hang, @Ho_Ten, @Dia_Chi, @So_Dien_Thoai, @Email)";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@Ma_Khach_Hang", maKhachHang);
                        command.Parameters.AddWithValue("@Ho_Ten", tenKhachHang);
                        command.Parameters.AddWithValue("@Dia_Chi", diaChi);
                        command.Parameters.AddWithValue("@So_Dien_Thoai", soDienThoai);
                        command.Parameters.AddWithValue("@Email", email);
                        command.ExecuteNonQuery();
                    }
                    MessageBox.Show("Thêm khách hàng thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Hienthithongkhachhang();
                    ClearFormKhachhang();
                }    
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi thêm khách hàng: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void ClearFormKhachhang()
        {
            txtMakhachhang.Text = "";
            txtTenkhachhang.Text = "";
            txtEmailkhachhang.Text = "";
            txtDiachikhachhang.Text = "";
            txtSdtkhachhang.Text = "";
            txtMakhachhang.ReadOnly = false;
        }

        private void btnXoakh_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvHienthithongtinkh.SelectedRows.Count == 0)
                {
                    MessageBox.Show("Vui lòng chọn khách hàng cần xóa!");
                    return;
                }
                DialogResult result = MessageBox.Show("Bạn có chắc chắn muốn xóa dữ liệu không?", "Xác nhận xóa", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    string maKhachHang = dgvHienthithongtinkh.SelectedRows[0].Cells["Ma_Khach_Hang"].Value.ToString();
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();

                        string query = "DELETE FROM Khach_Hang WHERE Ma_Khach_Hang = @Ma_Khach_Hang";
                        using (SqlCommand command = new SqlCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("@Ma_Khach_Hang", maKhachHang);
                            command.ExecuteNonQuery();
                        }
                    }
                    MessageBox.Show("Xóa dữ liệu thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Hienthithongkhachhang();
                    ClearFormKhachhang();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi xóa dữ liệu: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnSuakh_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvHienthithongtinkh.SelectedRows.Count == 0)
                {
                    MessageBox.Show("Vui lòng chọn khách hàng cần sửa!");
                    return;
                }
                DialogResult result = MessageBox.Show("Bạn có chắc chắn muốn sửa dữ liệu không?", "Xác nhận sửa", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    string maKhachHang = dgvHienthithongtinkh.SelectedRows[0].Cells["Ma_Khach_Hang"].Value.ToString();
                    string tenKhachHang = txtTenkhachhang.Text.Trim();
                    string diaChi = txtDiachikhachhang.Text.Trim();
                    string soDienThoai = txtSdtkhachhang.Text.Trim();
                    string email = txtEmailkhachhang.Text.Trim();

                    if (string.IsNullOrEmpty(maKhachHang) || string.IsNullOrEmpty(tenKhachHang) || string.IsNullOrEmpty(diaChi) || string.IsNullOrEmpty(soDienThoai) || string.IsNullOrEmpty(email))
                    {
                        MessageBox.Show("Vui lòng nhập đầy đủ thông tin bắt buộc!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();

                        string query = "UPDATE Khach_Hang SET Ho_Ten = @Ho_Ten, Dia_Chi = @Dia_Chi, So_Dien_Thoai = @So_Dien_Thoai, Email = @Email " +
                                       "WHERE Ma_Khach_Hang = @Ma_Khach_Hang";
                        using (SqlCommand command = new SqlCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("@Ma_Khach_Hang", maKhachHang);
                            command.Parameters.AddWithValue("@Ho_Ten", tenKhachHang);
                            command.Parameters.AddWithValue("@Dia_Chi", diaChi);
                            command.Parameters.AddWithValue("@So_Dien_Thoai", soDienThoai);
                            command.Parameters.AddWithValue("@Email", email);
                            command.ExecuteNonQuery();
                        }
                        MessageBox.Show("Sửa dữ liệu thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        Hienthithongkhachhang();
                        ClearFormKhachhang();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi sửa dữ liệu: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnTimkiemkh_Click(object sender, EventArgs e)
        {
            try
            {
                string maKhachHang = txtTimkiemkhachhang.Text.Trim();
                if (string.IsNullOrEmpty(maKhachHang))
                {
                    MessageBox.Show("Vui lòng nhập mã khách hàng để tìm kiếm!");
                    return;
                }    

                using(SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    string query = "SELECT kh.Ma_Khach_Hang, kh.Ho_Ten, kh.Dia_Chi, kh.So_Dien_Thoai, kh.Email " +
                                   "FROM Khach_Hang kh " +
                                   "WHERE kh.Ma_Khach_Hang LIKE @Ma_Khach_Hang";
                    using (SqlCommand command = new SqlCommand(query,connection))
                    {
                        command.Parameters.AddWithValue("@Ma_Khach_Hang", "%" + maKhachHang + "%");
                        using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                        {
                            DataSet dataSet = new DataSet();
                            adapter.Fill(dataSet);
                            dgvHienthithongtinkh.DataSource = dataSet.Tables[0];
                        }
                    }    
                }
                if (dgvHienthithongtinkh.Rows.Count == 0 || dgvHienthithongtinkh.Rows[0].IsNewRow)
                {
                    MessageBox.Show("Không tìm thấy mã khách hàng: " + maKhachHang + "!");
                }    
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi tìm kiếm dữ liệu: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnTailaikh_Click(object sender, EventArgs e)
        {
            Hienthithongkhachhang();
            ClearFormKhachhang();
            txtTimkiemkhachhang.Text = "";
        }

        private void btnQuaylaikh_Click(object sender, EventArgs e)
        {
            Caidat caidat = new Caidat();
            caidat.Show();
        }

        private void dgvHienthithongtinkh_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvHienthithongtinkh.SelectedRows.Count == 0) return;

            DataGridViewRow row = dgvHienthithongtinkh.SelectedRows[0];

            txtMakhachhang.Text = row.Cells["Ma_Khach_Hang"].Value?.ToString();
            txtTenkhachhang.Text = row.Cells["Ho_Ten"].Value?.ToString();
            txtDiachikhachhang.Text = row.Cells["Dia_Chi"].Value?.ToString();
            txtSdtkhachhang.Text = row.Cells["So_Dien_Thoai"].Value?.ToString();
            txtEmailkhachhang.Text = row.Cells["Email"].Value?.ToString();

            txtMakhachhang.ReadOnly = true;
        }
    }
}

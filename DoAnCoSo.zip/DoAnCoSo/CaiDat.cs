﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DoAnCoSo
{

    public partial class Caidat : Form
    {
        string connectionString = "Data Source=DESKTOP-T28R5TF\\SQLEXPRESS;Initial Catalog=QuanLyThoiTrangNu;User ID=sa;Password=123456;Integrated Security=True";

        public Caidat()
        {
            InitializeComponent();
            Hienthithongkhachhang();
            Hienthithongnhanvien();
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnTrangchu_Click(object sender, EventArgs e)
        {
            
        }

        private void btnKhachhang_Click(object sender, EventArgs e)
        {
            Khachhang khachhang = new Khachhang();
            khachhang.ShowDialog();
        }

        private void btnTaikhoan_Click(object sender, EventArgs e)
        {

        }

        private void btnNhanvien_Click(object sender, EventArgs e)
        {
            Nhanvien nhanvien = new Nhanvien();
            nhanvien.ShowDialog();
        }

        private void Hienthithongkhachhang()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT * FROM Khach_Hang";

                    using (SqlDataAdapter adapter = new SqlDataAdapter(query, connection))
                    {
                        DataSet dataSet = new DataSet();
                        adapter.Fill(dataSet);
                        dgvKh.DataSource = dataSet.Tables[0];
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi hiển thị danh sách khách hàng: " + ex.Message);
            }
        }

        private void Hienthithongnhanvien()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT * FROM Nhan_Vien";

                    using (SqlDataAdapter adapter = new SqlDataAdapter(query, connection))
                    {
                        DataSet dataSet = new DataSet();
                        adapter.Fill(dataSet);
                        dgvNv.DataSource = dataSet.Tables[0];
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi hiển thị danh sách nhân viên: " + ex.Message);
            }

        }
    }
}

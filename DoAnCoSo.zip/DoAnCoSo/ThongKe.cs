﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DoAnCoSo
{
    public partial class ThongKe : Form
    {
        public ThongKe()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Lấy ngày được chọn từ DateTimePicker
            DateTime ngayDuocChon = dateTimePicker1.Value.Date;

            // Chuỗi kết nối CSDL (thay thế bằng chuỗi của bạn)
            string connectionString = @"Data Source=DESKTOP-T28R5TF\SQLEXPRESS;Initial Catalog=QuanLyThoiTrangNu;Integrated Security=True";

            // Truy vấn SQL thống kê theo ngày
            string query = @"
        SELECT 
            sp.Ma_San_Pham,
            sp.Ten_San_Pham,
            SUM(cthd.So_Luong) AS Tong_So_Luong,
            SUM(cthd.Thanh_Tien) AS Tong_Thanh_Tien
        FROM Hoa_Don hd
        JOIN Chi_Tiet_Hoa_Don cthd ON hd.Ma_Hoa_Don = cthd.Ma_Hoa_Don
        JOIN San_Pham sp ON sp.Ma_San_Pham = cthd.Ma_San_Pham
        WHERE CAST(hd.Ngay_Lap AS DATE) = @NgayChon
        GROUP BY sp.Ma_San_Pham, sp.Ten_San_Pham";

            using (SqlConnection conn = new SqlConnection(connectionString))
            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("@NgayChon", ngayDuocChon);

                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                adapter.Fill(dt);

                // Hiển thị dữ liệu lên DataGridView
                dataGridView1.DataSource = dt;

                // Tính tổng thành tiền
                decimal tongTien = 0;
                foreach (DataRow row in dt.Rows)
                {
                    tongTien += Convert.ToDecimal(row["Tong_Thanh_Tien"]);
                }

                // Hiển thị tổng
                label1.Text = "Tổng thành tiền: " + tongTien.ToString("N0") + " VNĐ";
            }
        }
    }
}

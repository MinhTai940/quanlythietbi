﻿namespace DoAnCoSo
{
    partial class Nhanvien
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Nhanvien));
            this.label8 = new System.Windows.Forms.Label();
            this.txtManhanvien = new System.Windows.Forms.TextBox();
            this.txtTennhanvien = new System.Windows.Forms.TextBox();
            this.txtVaitro = new System.Windows.Forms.TextBox();
            this.txtMatkhaunhanvien = new System.Windows.Forms.TextBox();
            this.txtEmailnhanvien = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnTimKiemNhanVien = new Guna.UI2.WinForms.Guna2ImageButton();
            this.txtTimkiemnhanvien = new Guna.UI2.WinForms.Guna2TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.btnQuaylainv = new Guna.UI2.WinForms.Guna2Button();
            this.btnTailainv = new Guna.UI2.WinForms.Guna2Button();
            this.btnSuanv = new Guna.UI2.WinForms.Guna2Button();
            this.btnXoanv = new Guna.UI2.WinForms.Guna2Button();
            this.btnThemnv = new Guna.UI2.WinForms.Guna2Button();
            this.txtSdtnhanvien = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.guna2GroupBox1 = new Guna.UI2.WinForms.Guna2GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.dgvHienthithongtinnv = new System.Windows.Forms.DataGridView();
            this.groupBox2.SuspendLayout();
            this.guna2GroupBox1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHienthithongtinnv)).BeginInit();
            this.SuspendLayout();
            // 
            // label8
            // 
            this.label8.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label8.Location = new System.Drawing.Point(563, 33);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(349, 61);
            this.label8.TabIndex = 49;
            this.label8.Text = "Quản Lý Nhân Viên";
            // 
            // txtManhanvien
            // 
            this.txtManhanvien.Location = new System.Drawing.Point(171, 94);
            this.txtManhanvien.Multiline = true;
            this.txtManhanvien.Name = "txtManhanvien";
            this.txtManhanvien.Size = new System.Drawing.Size(350, 30);
            this.txtManhanvien.TabIndex = 41;
            // 
            // txtTennhanvien
            // 
            this.txtTennhanvien.Location = new System.Drawing.Point(171, 148);
            this.txtTennhanvien.Multiline = true;
            this.txtTennhanvien.Name = "txtTennhanvien";
            this.txtTennhanvien.Size = new System.Drawing.Size(350, 30);
            this.txtTennhanvien.TabIndex = 40;
            // 
            // txtVaitro
            // 
            this.txtVaitro.Location = new System.Drawing.Point(171, 256);
            this.txtVaitro.Multiline = true;
            this.txtVaitro.Name = "txtVaitro";
            this.txtVaitro.Size = new System.Drawing.Size(350, 30);
            this.txtVaitro.TabIndex = 39;
            // 
            // txtMatkhaunhanvien
            // 
            this.txtMatkhaunhanvien.Location = new System.Drawing.Point(171, 203);
            this.txtMatkhaunhanvien.Multiline = true;
            this.txtMatkhaunhanvien.Name = "txtMatkhaunhanvien";
            this.txtMatkhaunhanvien.Size = new System.Drawing.Size(350, 30);
            this.txtMatkhaunhanvien.TabIndex = 38;
            // 
            // txtEmailnhanvien
            // 
            this.txtEmailnhanvien.Location = new System.Drawing.Point(171, 354);
            this.txtEmailnhanvien.Multiline = true;
            this.txtEmailnhanvien.Name = "txtEmailnhanvien";
            this.txtEmailnhanvien.Size = new System.Drawing.Size(350, 30);
            this.txtEmailnhanvien.TabIndex = 37;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(38, 151);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(110, 19);
            this.label5.TabIndex = 36;
            this.label5.Text = "Tên nhân viên";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(38, 206);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(78, 19);
            this.label4.TabIndex = 35;
            this.label4.Text = "Mật khẩu";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(38, 259);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(59, 19);
            this.label3.TabIndex = 34;
            this.label3.Text = "Vai trò";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(38, 357);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(54, 19);
            this.label2.TabIndex = 33;
            this.label2.Text = "Email";
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(33, 94);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(110, 27);
            this.label1.TabIndex = 32;
            this.label1.Text = "Mã nhân viên";
            // 
            // btnTimKiemNhanVien
            // 
            this.btnTimKiemNhanVien.CheckedState.ImageSize = new System.Drawing.Size(64, 64);
            this.btnTimKiemNhanVien.HoverState.ImageSize = new System.Drawing.Size(64, 64);
            this.btnTimKiemNhanVien.Image = ((System.Drawing.Image)(resources.GetObject("btnTimKiemNhanVien.Image")));
            this.btnTimKiemNhanVien.ImageOffset = new System.Drawing.Point(0, 0);
            this.btnTimKiemNhanVien.ImageRotate = 0F;
            this.btnTimKiemNhanVien.Location = new System.Drawing.Point(630, 56);
            this.btnTimKiemNhanVien.Name = "btnTimKiemNhanVien";
            this.btnTimKiemNhanVien.PressedState.ImageSize = new System.Drawing.Size(64, 64);
            this.btnTimKiemNhanVien.Size = new System.Drawing.Size(64, 54);
            this.btnTimKiemNhanVien.TabIndex = 8;
            this.btnTimKiemNhanVien.Click += new System.EventHandler(this.btnTimKiemNhanVien_Click);
            // 
            // txtTimkiemnhanvien
            // 
            this.txtTimkiemnhanvien.BorderRadius = 15;
            this.txtTimkiemnhanvien.BorderStyle = System.Drawing.Drawing2D.DashStyle.Custom;
            this.txtTimkiemnhanvien.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtTimkiemnhanvien.DefaultText = "";
            this.txtTimkiemnhanvien.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtTimkiemnhanvien.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtTimkiemnhanvien.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtTimkiemnhanvien.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtTimkiemnhanvien.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtTimkiemnhanvien.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtTimkiemnhanvien.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtTimkiemnhanvien.Location = new System.Drawing.Point(24, 56);
            this.txtTimkiemnhanvien.Name = "txtTimkiemnhanvien";
            this.txtTimkiemnhanvien.PasswordChar = '\0';
            this.txtTimkiemnhanvien.PlaceholderText = "";
            this.txtTimkiemnhanvien.SelectedText = "";
            this.txtTimkiemnhanvien.Size = new System.Drawing.Size(600, 54);
            this.txtTimkiemnhanvien.TabIndex = 7;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(61, 56);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(80, 19);
            this.label6.TabIndex = 6;
            this.label6.Text = "Tìm kiếm";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(38, 309);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(105, 19);
            this.label7.TabIndex = 42;
            this.label7.Text = "Số điện thoại";
            // 
            // btnQuaylainv
            // 
            this.btnQuaylainv.BorderRadius = 20;
            this.btnQuaylainv.BorderThickness = 1;
            this.btnQuaylainv.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnQuaylainv.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnQuaylainv.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnQuaylainv.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnQuaylainv.FillColor = System.Drawing.Color.LightCoral;
            this.btnQuaylainv.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnQuaylainv.ForeColor = System.Drawing.Color.White;
            this.btnQuaylainv.HoverState.BorderColor = System.Drawing.Color.LightCoral;
            this.btnQuaylainv.HoverState.FillColor = System.Drawing.Color.White;
            this.btnQuaylainv.HoverState.ForeColor = System.Drawing.Color.LightCoral;
            this.btnQuaylainv.Location = new System.Drawing.Point(494, 109);
            this.btnQuaylainv.Name = "btnQuaylainv";
            this.btnQuaylainv.Size = new System.Drawing.Size(200, 60);
            this.btnQuaylainv.TabIndex = 36;
            this.btnQuaylainv.Text = "Quay lại";
            this.btnQuaylainv.Click += new System.EventHandler(this.btnQuaylainv_Click);
            // 
            // btnTailainv
            // 
            this.btnTailainv.BorderRadius = 20;
            this.btnTailainv.BorderThickness = 1;
            this.btnTailainv.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnTailainv.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnTailainv.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnTailainv.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnTailainv.FillColor = System.Drawing.Color.LightCoral;
            this.btnTailainv.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTailainv.ForeColor = System.Drawing.Color.White;
            this.btnTailainv.HoverState.BorderColor = System.Drawing.Color.LightCoral;
            this.btnTailainv.HoverState.FillColor = System.Drawing.Color.White;
            this.btnTailainv.HoverState.ForeColor = System.Drawing.Color.LightCoral;
            this.btnTailainv.Location = new System.Drawing.Point(261, 109);
            this.btnTailainv.Name = "btnTailainv";
            this.btnTailainv.Size = new System.Drawing.Size(200, 60);
            this.btnTailainv.TabIndex = 36;
            this.btnTailainv.Text = "Tải lại";
            this.btnTailainv.Click += new System.EventHandler(this.btnTailainv_Click);
            // 
            // btnSuanv
            // 
            this.btnSuanv.BorderRadius = 20;
            this.btnSuanv.BorderThickness = 1;
            this.btnSuanv.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnSuanv.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnSuanv.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnSuanv.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnSuanv.FillColor = System.Drawing.Color.LightCoral;
            this.btnSuanv.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSuanv.ForeColor = System.Drawing.Color.White;
            this.btnSuanv.HoverState.BorderColor = System.Drawing.Color.LightCoral;
            this.btnSuanv.HoverState.FillColor = System.Drawing.Color.White;
            this.btnSuanv.HoverState.ForeColor = System.Drawing.Color.LightCoral;
            this.btnSuanv.Location = new System.Drawing.Point(24, 109);
            this.btnSuanv.Name = "btnSuanv";
            this.btnSuanv.Size = new System.Drawing.Size(200, 60);
            this.btnSuanv.TabIndex = 36;
            this.btnSuanv.Text = "Sửa nhân viên";
            this.btnSuanv.Click += new System.EventHandler(this.btnSuanv_Click);
            // 
            // btnXoanv
            // 
            this.btnXoanv.BorderRadius = 20;
            this.btnXoanv.BorderThickness = 1;
            this.btnXoanv.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnXoanv.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnXoanv.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnXoanv.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnXoanv.FillColor = System.Drawing.Color.LightCoral;
            this.btnXoanv.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXoanv.ForeColor = System.Drawing.Color.White;
            this.btnXoanv.HoverState.BorderColor = System.Drawing.Color.LightCoral;
            this.btnXoanv.HoverState.FillColor = System.Drawing.Color.White;
            this.btnXoanv.HoverState.ForeColor = System.Drawing.Color.LightCoral;
            this.btnXoanv.Location = new System.Drawing.Point(261, 26);
            this.btnXoanv.Name = "btnXoanv";
            this.btnXoanv.Size = new System.Drawing.Size(200, 60);
            this.btnXoanv.TabIndex = 35;
            this.btnXoanv.Text = "Xóa nhân viên";
            this.btnXoanv.Click += new System.EventHandler(this.btnXoanv_Click);
            // 
            // btnThemnv
            // 
            this.btnThemnv.BorderRadius = 20;
            this.btnThemnv.BorderThickness = 1;
            this.btnThemnv.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnThemnv.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnThemnv.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnThemnv.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnThemnv.FillColor = System.Drawing.Color.LightCoral;
            this.btnThemnv.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThemnv.ForeColor = System.Drawing.Color.White;
            this.btnThemnv.HoverState.BorderColor = System.Drawing.Color.LightCoral;
            this.btnThemnv.HoverState.FillColor = System.Drawing.Color.White;
            this.btnThemnv.HoverState.ForeColor = System.Drawing.Color.LightCoral;
            this.btnThemnv.Location = new System.Drawing.Point(24, 26);
            this.btnThemnv.Name = "btnThemnv";
            this.btnThemnv.Size = new System.Drawing.Size(200, 60);
            this.btnThemnv.TabIndex = 34;
            this.btnThemnv.Text = "Thêm nhân viên";
            this.btnThemnv.Click += new System.EventHandler(this.btnThemnv_Click);
            // 
            // txtSdtnhanvien
            // 
            this.txtSdtnhanvien.Location = new System.Drawing.Point(171, 306);
            this.txtSdtnhanvien.Multiline = true;
            this.txtSdtnhanvien.Name = "txtSdtnhanvien";
            this.txtSdtnhanvien.Size = new System.Drawing.Size(350, 30);
            this.txtSdtnhanvien.TabIndex = 43;
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.White;
            this.groupBox2.Controls.Add(this.btnQuaylainv);
            this.groupBox2.Controls.Add(this.btnTailainv);
            this.groupBox2.Controls.Add(this.btnSuanv);
            this.groupBox2.Controls.Add(this.btnXoanv);
            this.groupBox2.Controls.Add(this.btnThemnv);
            this.groupBox2.Location = new System.Drawing.Point(631, 215);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(712, 198);
            this.groupBox2.TabIndex = 44;
            this.groupBox2.TabStop = false;
            // 
            // guna2GroupBox1
            // 
            this.guna2GroupBox1.Controls.Add(this.txtSdtnhanvien);
            this.guna2GroupBox1.Controls.Add(this.groupBox2);
            this.guna2GroupBox1.Controls.Add(this.label7);
            this.guna2GroupBox1.Controls.Add(this.groupBox3);
            this.guna2GroupBox1.Controls.Add(this.txtManhanvien);
            this.guna2GroupBox1.Controls.Add(this.txtTennhanvien);
            this.guna2GroupBox1.Controls.Add(this.txtVaitro);
            this.guna2GroupBox1.Controls.Add(this.txtMatkhaunhanvien);
            this.guna2GroupBox1.Controls.Add(this.txtEmailnhanvien);
            this.guna2GroupBox1.Controls.Add(this.label5);
            this.guna2GroupBox1.Controls.Add(this.label4);
            this.guna2GroupBox1.Controls.Add(this.label3);
            this.guna2GroupBox1.Controls.Add(this.label2);
            this.guna2GroupBox1.Controls.Add(this.label1);
            this.guna2GroupBox1.CustomBorderColor = System.Drawing.Color.LightCoral;
            this.guna2GroupBox1.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.guna2GroupBox1.ForeColor = System.Drawing.Color.White;
            this.guna2GroupBox1.Location = new System.Drawing.Point(12, 111);
            this.guna2GroupBox1.Name = "guna2GroupBox1";
            this.guna2GroupBox1.Size = new System.Drawing.Size(1412, 420);
            this.guna2GroupBox1.TabIndex = 48;
            this.guna2GroupBox1.Text = "Thông Tin Nhân Viên";
            // 
            // groupBox3
            // 
            this.groupBox3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox3.BackColor = System.Drawing.Color.White;
            this.groupBox3.Controls.Add(this.btnTimKiemNhanVien);
            this.groupBox3.Controls.Add(this.txtTimkiemnhanvien);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Location = new System.Drawing.Point(631, 60);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(712, 166);
            this.groupBox3.TabIndex = 45;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Tìm kiếm";
            // 
            // dgvHienthithongtinnv
            // 
            this.dgvHienthithongtinnv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvHienthithongtinnv.Location = new System.Drawing.Point(12, 552);
            this.dgvHienthithongtinnv.Name = "dgvHienthithongtinnv";
            this.dgvHienthithongtinnv.RowHeadersWidth = 51;
            this.dgvHienthithongtinnv.RowTemplate.Height = 24;
            this.dgvHienthithongtinnv.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvHienthithongtinnv.Size = new System.Drawing.Size(1412, 233);
            this.dgvHienthithongtinnv.TabIndex = 47;
            this.dgvHienthithongtinnv.SelectionChanged += new System.EventHandler(this.dgvHienthithongtinnv_SelectionChanged);
            // 
            // Nhanvien
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1436, 818);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.guna2GroupBox1);
            this.Controls.Add(this.dgvHienthithongtinnv);
            this.Font = new System.Drawing.Font("Times New Roman", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "Nhanvien";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Nhân viên";
            this.groupBox2.ResumeLayout(false);
            this.guna2GroupBox1.ResumeLayout(false);
            this.guna2GroupBox1.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHienthithongtinnv)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtManhanvien;
        private System.Windows.Forms.TextBox txtTennhanvien;
        private System.Windows.Forms.TextBox txtVaitro;
        private System.Windows.Forms.TextBox txtMatkhaunhanvien;
        private System.Windows.Forms.TextBox txtEmailnhanvien;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private Guna.UI2.WinForms.Guna2ImageButton btnTimKiemNhanVien;
        private Guna.UI2.WinForms.Guna2TextBox txtTimkiemnhanvien;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private Guna.UI2.WinForms.Guna2Button btnQuaylainv;
        private Guna.UI2.WinForms.Guna2Button btnTailainv;
        private Guna.UI2.WinForms.Guna2Button btnSuanv;
        private Guna.UI2.WinForms.Guna2Button btnXoanv;
        private Guna.UI2.WinForms.Guna2Button btnThemnv;
        private System.Windows.Forms.TextBox txtSdtnhanvien;
        private System.Windows.Forms.GroupBox groupBox2;
        private Guna.UI2.WinForms.Guna2GroupBox guna2GroupBox1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.DataGridView dgvHienthithongtinnv;
    }
}
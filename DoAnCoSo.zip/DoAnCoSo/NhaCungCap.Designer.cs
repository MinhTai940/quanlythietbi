﻿namespace DoAnCoSo
{
    partial class Nhacungcap
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Nhacungcap));
            this.label8 = new System.Windows.Forms.Label();
            this.txtTennhacungcap = new System.Windows.Forms.TextBox();
            this.txtSdtnhacungcap = new System.Windows.Forms.TextBox();
            this.txtEmailnhacungcap = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnQuaylaincc = new Guna.UI2.WinForms.Guna2Button();
            this.btnTailaincc = new Guna.UI2.WinForms.Guna2Button();
            this.btnSuancc = new Guna.UI2.WinForms.Guna2Button();
            this.label7 = new System.Windows.Forms.Label();
            this.txtManhacungcap = new System.Windows.Forms.TextBox();
            this.btnThemncc = new Guna.UI2.WinForms.Guna2Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnXoancc = new Guna.UI2.WinForms.Guna2Button();
            this.label1 = new System.Windows.Forms.Label();
            this.btnTimkiemncc = new Guna.UI2.WinForms.Guna2ImageButton();
            this.txtTimkiemnhacungcap = new Guna.UI2.WinForms.Guna2TextBox();
            this.txtDiachinhacungcap = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.guna2GroupBox1 = new Guna.UI2.WinForms.Guna2GroupBox();
            this.dgvHienthithongtinncc = new System.Windows.Forms.DataGridView();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.guna2GroupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHienthithongtinncc)).BeginInit();
            this.SuspendLayout();
            // 
            // label8
            // 
            this.label8.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label8.Location = new System.Drawing.Point(522, 9);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(395, 61);
            this.label8.TabIndex = 50;
            this.label8.Text = "Quản lý nhà cung cấp";
            // 
            // txtTennhacungcap
            // 
            this.txtTennhacungcap.Location = new System.Drawing.Point(190, 157);
            this.txtTennhacungcap.Multiline = true;
            this.txtTennhacungcap.Name = "txtTennhacungcap";
            this.txtTennhacungcap.Size = new System.Drawing.Size(350, 30);
            this.txtTennhacungcap.TabIndex = 42;
            // 
            // txtSdtnhacungcap
            // 
            this.txtSdtnhacungcap.Location = new System.Drawing.Point(190, 219);
            this.txtSdtnhacungcap.Multiline = true;
            this.txtSdtnhacungcap.Name = "txtSdtnhacungcap";
            this.txtSdtnhacungcap.Size = new System.Drawing.Size(350, 30);
            this.txtSdtnhacungcap.TabIndex = 41;
            // 
            // txtEmailnhacungcap
            // 
            this.txtEmailnhacungcap.Location = new System.Drawing.Point(190, 346);
            this.txtEmailnhacungcap.Multiline = true;
            this.txtEmailnhacungcap.Name = "txtEmailnhacungcap";
            this.txtEmailnhacungcap.Size = new System.Drawing.Size(350, 30);
            this.txtEmailnhacungcap.TabIndex = 40;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(47, 160);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(134, 19);
            this.label5.TabIndex = 39;
            this.label5.Text = "Tên nhà cung cấp";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(47, 222);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(105, 19);
            this.label4.TabIndex = 38;
            this.label4.Text = "Số điện thoại";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(47, 349);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(54, 19);
            this.label2.TabIndex = 37;
            this.label2.Text = "Email";
            // 
            // btnQuaylaincc
            // 
            this.btnQuaylaincc.BorderRadius = 20;
            this.btnQuaylaincc.BorderThickness = 1;
            this.btnQuaylaincc.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnQuaylaincc.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnQuaylaincc.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnQuaylaincc.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnQuaylaincc.FillColor = System.Drawing.Color.LightCoral;
            this.btnQuaylaincc.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnQuaylaincc.ForeColor = System.Drawing.Color.White;
            this.btnQuaylaincc.HoverState.BorderColor = System.Drawing.Color.LightCoral;
            this.btnQuaylaincc.HoverState.FillColor = System.Drawing.Color.White;
            this.btnQuaylaincc.HoverState.ForeColor = System.Drawing.Color.LightCoral;
            this.btnQuaylaincc.Location = new System.Drawing.Point(491, 111);
            this.btnQuaylaincc.Name = "btnQuaylaincc";
            this.btnQuaylaincc.Size = new System.Drawing.Size(200, 60);
            this.btnQuaylaincc.TabIndex = 41;
            this.btnQuaylaincc.Text = "Quay lại";
            this.btnQuaylaincc.Click += new System.EventHandler(this.btnQuaylaincc_Click);
            // 
            // btnTailaincc
            // 
            this.btnTailaincc.BorderRadius = 20;
            this.btnTailaincc.BorderThickness = 1;
            this.btnTailaincc.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnTailaincc.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnTailaincc.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnTailaincc.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnTailaincc.FillColor = System.Drawing.Color.LightCoral;
            this.btnTailaincc.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTailaincc.ForeColor = System.Drawing.Color.White;
            this.btnTailaincc.HoverState.BorderColor = System.Drawing.Color.LightCoral;
            this.btnTailaincc.HoverState.FillColor = System.Drawing.Color.White;
            this.btnTailaincc.HoverState.ForeColor = System.Drawing.Color.LightCoral;
            this.btnTailaincc.Location = new System.Drawing.Point(282, 111);
            this.btnTailaincc.Name = "btnTailaincc";
            this.btnTailaincc.Size = new System.Drawing.Size(200, 60);
            this.btnTailaincc.TabIndex = 39;
            this.btnTailaincc.Text = "Tải lại";
            this.btnTailaincc.Click += new System.EventHandler(this.btnTailaincc_Click);
            // 
            // btnSuancc
            // 
            this.btnSuancc.BorderRadius = 20;
            this.btnSuancc.BorderThickness = 1;
            this.btnSuancc.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnSuancc.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnSuancc.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnSuancc.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnSuancc.FillColor = System.Drawing.Color.LightCoral;
            this.btnSuancc.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSuancc.ForeColor = System.Drawing.Color.White;
            this.btnSuancc.HoverState.BorderColor = System.Drawing.Color.LightCoral;
            this.btnSuancc.HoverState.FillColor = System.Drawing.Color.White;
            this.btnSuancc.HoverState.ForeColor = System.Drawing.Color.LightCoral;
            this.btnSuancc.Location = new System.Drawing.Point(40, 111);
            this.btnSuancc.Name = "btnSuancc";
            this.btnSuancc.Size = new System.Drawing.Size(200, 60);
            this.btnSuancc.TabIndex = 40;
            this.btnSuancc.Text = "Sửa nhà cung cấp";
            this.btnSuancc.Click += new System.EventHandler(this.btnSuancc_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(47, 288);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(62, 19);
            this.label7.TabIndex = 44;
            this.label7.Text = "Địa chỉ";
            // 
            // txtManhacungcap
            // 
            this.txtManhacungcap.Location = new System.Drawing.Point(190, 98);
            this.txtManhacungcap.Multiline = true;
            this.txtManhacungcap.Name = "txtManhacungcap";
            this.txtManhacungcap.Size = new System.Drawing.Size(350, 30);
            this.txtManhacungcap.TabIndex = 43;
            // 
            // btnThemncc
            // 
            this.btnThemncc.BorderRadius = 20;
            this.btnThemncc.BorderThickness = 1;
            this.btnThemncc.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnThemncc.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnThemncc.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnThemncc.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnThemncc.FillColor = System.Drawing.Color.LightCoral;
            this.btnThemncc.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThemncc.ForeColor = System.Drawing.Color.White;
            this.btnThemncc.HoverState.BorderColor = System.Drawing.Color.LightCoral;
            this.btnThemncc.HoverState.FillColor = System.Drawing.Color.White;
            this.btnThemncc.HoverState.ForeColor = System.Drawing.Color.LightCoral;
            this.btnThemncc.Location = new System.Drawing.Point(40, 30);
            this.btnThemncc.Name = "btnThemncc";
            this.btnThemncc.Size = new System.Drawing.Size(200, 60);
            this.btnThemncc.TabIndex = 37;
            this.btnThemncc.Text = "Thêm nhà cung cấp";
            this.btnThemncc.Click += new System.EventHandler(this.btnThemncc_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.White;
            this.groupBox2.Controls.Add(this.btnQuaylaincc);
            this.groupBox2.Controls.Add(this.btnTailaincc);
            this.groupBox2.Controls.Add(this.btnSuancc);
            this.groupBox2.Controls.Add(this.btnThemncc);
            this.groupBox2.Controls.Add(this.btnXoancc);
            this.groupBox2.Location = new System.Drawing.Point(646, 205);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(712, 198);
            this.groupBox2.TabIndex = 46;
            this.groupBox2.TabStop = false;
            // 
            // btnXoancc
            // 
            this.btnXoancc.BorderRadius = 20;
            this.btnXoancc.BorderThickness = 1;
            this.btnXoancc.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnXoancc.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnXoancc.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnXoancc.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnXoancc.FillColor = System.Drawing.Color.LightCoral;
            this.btnXoancc.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXoancc.ForeColor = System.Drawing.Color.White;
            this.btnXoancc.HoverState.BorderColor = System.Drawing.Color.LightCoral;
            this.btnXoancc.HoverState.FillColor = System.Drawing.Color.White;
            this.btnXoancc.HoverState.ForeColor = System.Drawing.Color.LightCoral;
            this.btnXoancc.Location = new System.Drawing.Point(282, 30);
            this.btnXoancc.Name = "btnXoancc";
            this.btnXoancc.Size = new System.Drawing.Size(200, 60);
            this.btnXoancc.TabIndex = 38;
            this.btnXoancc.Text = "Xóa nhà cung cấp";
            this.btnXoancc.Click += new System.EventHandler(this.btnXoancc_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(47, 101);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(131, 19);
            this.label1.TabIndex = 36;
            this.label1.Text = "Mã nhà cung cấp";
            // 
            // btnTimkiemncc
            // 
            this.btnTimkiemncc.CheckedState.ImageSize = new System.Drawing.Size(64, 64);
            this.btnTimkiemncc.HoverState.ImageSize = new System.Drawing.Size(64, 64);
            this.btnTimkiemncc.Image = ((System.Drawing.Image)(resources.GetObject("btnTimkiemncc.Image")));
            this.btnTimkiemncc.ImageOffset = new System.Drawing.Point(0, 0);
            this.btnTimkiemncc.ImageRotate = 0F;
            this.btnTimkiemncc.Location = new System.Drawing.Point(627, 36);
            this.btnTimkiemncc.Name = "btnTimkiemncc";
            this.btnTimkiemncc.PressedState.ImageSize = new System.Drawing.Size(64, 64);
            this.btnTimkiemncc.Size = new System.Drawing.Size(64, 54);
            this.btnTimkiemncc.TabIndex = 10;
            this.btnTimkiemncc.Click += new System.EventHandler(this.btnTimkiemncc_Click);
            // 
            // txtTimkiemnhacungcap
            // 
            this.txtTimkiemnhacungcap.BorderRadius = 15;
            this.txtTimkiemnhacungcap.BorderStyle = System.Drawing.Drawing2D.DashStyle.Custom;
            this.txtTimkiemnhacungcap.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtTimkiemnhacungcap.DefaultText = "";
            this.txtTimkiemnhacungcap.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtTimkiemnhacungcap.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtTimkiemnhacungcap.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtTimkiemnhacungcap.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtTimkiemnhacungcap.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtTimkiemnhacungcap.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtTimkiemnhacungcap.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtTimkiemnhacungcap.Location = new System.Drawing.Point(21, 36);
            this.txtTimkiemnhacungcap.Name = "txtTimkiemnhacungcap";
            this.txtTimkiemnhacungcap.PasswordChar = '\0';
            this.txtTimkiemnhacungcap.PlaceholderText = "";
            this.txtTimkiemnhacungcap.SelectedText = "";
            this.txtTimkiemnhacungcap.Size = new System.Drawing.Size(600, 54);
            this.txtTimkiemnhacungcap.TabIndex = 9;
            // 
            // txtDiachinhacungcap
            // 
            this.txtDiachinhacungcap.Location = new System.Drawing.Point(190, 285);
            this.txtDiachinhacungcap.Multiline = true;
            this.txtDiachinhacungcap.Name = "txtDiachinhacungcap";
            this.txtDiachinhacungcap.Size = new System.Drawing.Size(350, 30);
            this.txtDiachinhacungcap.TabIndex = 45;
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.Color.White;
            this.groupBox3.Controls.Add(this.btnTimkiemncc);
            this.groupBox3.Controls.Add(this.txtTimkiemnhacungcap);
            this.groupBox3.Location = new System.Drawing.Point(646, 60);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(712, 127);
            this.groupBox3.TabIndex = 47;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Tìm Kiếm";
            // 
            // guna2GroupBox1
            // 
            this.guna2GroupBox1.Controls.Add(this.txtDiachinhacungcap);
            this.guna2GroupBox1.Controls.Add(this.groupBox3);
            this.guna2GroupBox1.Controls.Add(this.groupBox2);
            this.guna2GroupBox1.Controls.Add(this.label7);
            this.guna2GroupBox1.Controls.Add(this.txtManhacungcap);
            this.guna2GroupBox1.Controls.Add(this.txtTennhacungcap);
            this.guna2GroupBox1.Controls.Add(this.txtSdtnhacungcap);
            this.guna2GroupBox1.Controls.Add(this.txtEmailnhacungcap);
            this.guna2GroupBox1.Controls.Add(this.label5);
            this.guna2GroupBox1.Controls.Add(this.label4);
            this.guna2GroupBox1.Controls.Add(this.label2);
            this.guna2GroupBox1.Controls.Add(this.label1);
            this.guna2GroupBox1.CustomBorderColor = System.Drawing.Color.LightCoral;
            this.guna2GroupBox1.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.guna2GroupBox1.ForeColor = System.Drawing.Color.White;
            this.guna2GroupBox1.Location = new System.Drawing.Point(12, 74);
            this.guna2GroupBox1.Name = "guna2GroupBox1";
            this.guna2GroupBox1.Size = new System.Drawing.Size(1412, 420);
            this.guna2GroupBox1.TabIndex = 49;
            this.guna2GroupBox1.Text = "Thông Tin Nhà Cung Cấp";
            // 
            // dgvHienthithongtinncc
            // 
            this.dgvHienthithongtinncc.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvHienthithongtinncc.Location = new System.Drawing.Point(12, 517);
            this.dgvHienthithongtinncc.Name = "dgvHienthithongtinncc";
            this.dgvHienthithongtinncc.RowHeadersWidth = 51;
            this.dgvHienthithongtinncc.RowTemplate.Height = 24;
            this.dgvHienthithongtinncc.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvHienthithongtinncc.Size = new System.Drawing.Size(1412, 289);
            this.dgvHienthithongtinncc.TabIndex = 48;
            this.dgvHienthithongtinncc.SelectionChanged += new System.EventHandler(this.dgvHienthithongtinncc_SelectionChanged);
            // 
            // Nhacungcap
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1436, 818);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.guna2GroupBox1);
            this.Controls.Add(this.dgvHienthithongtinncc);
            this.Name = "Nhacungcap";
            this.Text = "Nhà cung cấp";
            this.groupBox2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.guna2GroupBox1.ResumeLayout(false);
            this.guna2GroupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHienthithongtinncc)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtTennhacungcap;
        private System.Windows.Forms.TextBox txtSdtnhacungcap;
        private System.Windows.Forms.TextBox txtEmailnhacungcap;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private Guna.UI2.WinForms.Guna2Button btnQuaylaincc;
        private Guna.UI2.WinForms.Guna2Button btnTailaincc;
        private Guna.UI2.WinForms.Guna2Button btnSuancc;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtManhacungcap;
        private Guna.UI2.WinForms.Guna2Button btnThemncc;
        private System.Windows.Forms.GroupBox groupBox2;
        private Guna.UI2.WinForms.Guna2Button btnXoancc;
        private System.Windows.Forms.Label label1;
        private Guna.UI2.WinForms.Guna2ImageButton btnTimkiemncc;
        private Guna.UI2.WinForms.Guna2TextBox txtTimkiemnhacungcap;
        private System.Windows.Forms.TextBox txtDiachinhacungcap;
        private System.Windows.Forms.GroupBox groupBox3;
        private Guna.UI2.WinForms.Guna2GroupBox guna2GroupBox1;
        private System.Windows.Forms.DataGridView dgvHienthithongtinncc;
    }
}
﻿namespace DoAnCoSo
{
    partial class Hoadon
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label8 = new System.Windows.Forms.Label();
            this.cmbMakhachhang = new Guna.UI2.WinForms.Guna2ComboBox();
            this.guna2GroupBox1 = new Guna.UI2.WinForms.Guna2GroupBox();
            this.cmbManhanvien = new Guna.UI2.WinForms.Guna2ComboBox();
            this.dtpNgaylaphd = new System.Windows.Forms.DateTimePicker();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txtMahoadon = new System.Windows.Forms.TextBox();
            this.txtTongtien = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dgvHoadon = new System.Windows.Forms.DataGridView();
            this.btnLuuhd = new Guna.UI2.WinForms.Guna2Button();
            this.btnXoahd = new Guna.UI2.WinForms.Guna2Button();
            this.btnThemhd = new Guna.UI2.WinForms.Guna2Button();
            this.btnSuahd = new Guna.UI2.WinForms.Guna2Button();
            this.btnHuyhd = new Guna.UI2.WinForms.Guna2Button();
            this.guna2GroupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHoadon)).BeginInit();
            this.SuspendLayout();
            // 
            // label8
            // 
            this.label8.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label8.Location = new System.Drawing.Point(476, 9);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(395, 61);
            this.label8.TabIndex = 57;
            this.label8.Text = "Quản lý hóa đơn";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cmbMakhachhang
            // 
            this.cmbMakhachhang.BackColor = System.Drawing.Color.Transparent;
            this.cmbMakhachhang.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cmbMakhachhang.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbMakhachhang.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cmbMakhachhang.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cmbMakhachhang.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.cmbMakhachhang.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(88)))), ((int)(((byte)(112)))));
            this.cmbMakhachhang.ItemHeight = 30;
            this.cmbMakhachhang.Location = new System.Drawing.Point(758, 165);
            this.cmbMakhachhang.Name = "cmbMakhachhang";
            this.cmbMakhachhang.Size = new System.Drawing.Size(350, 36);
            this.cmbMakhachhang.TabIndex = 39;
            // 
            // guna2GroupBox1
            // 
            this.guna2GroupBox1.Controls.Add(this.cmbMakhachhang);
            this.guna2GroupBox1.Controls.Add(this.cmbManhanvien);
            this.guna2GroupBox1.Controls.Add(this.dtpNgaylaphd);
            this.guna2GroupBox1.Controls.Add(this.label3);
            this.guna2GroupBox1.Controls.Add(this.label2);
            this.guna2GroupBox1.Controls.Add(this.label9);
            this.guna2GroupBox1.Controls.Add(this.txtMahoadon);
            this.guna2GroupBox1.Controls.Add(this.txtTongtien);
            this.guna2GroupBox1.Controls.Add(this.label5);
            this.guna2GroupBox1.Controls.Add(this.label1);
            this.guna2GroupBox1.CustomBorderColor = System.Drawing.Color.LightCoral;
            this.guna2GroupBox1.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.guna2GroupBox1.ForeColor = System.Drawing.Color.White;
            this.guna2GroupBox1.Location = new System.Drawing.Point(13, 84);
            this.guna2GroupBox1.Name = "guna2GroupBox1";
            this.guna2GroupBox1.Size = new System.Drawing.Size(1412, 314);
            this.guna2GroupBox1.TabIndex = 51;
            this.guna2GroupBox1.Text = "Thông Tin Hóa Đơn";
            // 
            // cmbManhanvien
            // 
            this.cmbManhanvien.BackColor = System.Drawing.Color.Transparent;
            this.cmbManhanvien.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cmbManhanvien.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbManhanvien.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cmbManhanvien.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cmbManhanvien.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.cmbManhanvien.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(88)))), ((int)(((byte)(112)))));
            this.cmbManhanvien.ItemHeight = 30;
            this.cmbManhanvien.Location = new System.Drawing.Point(758, 84);
            this.cmbManhanvien.Name = "cmbManhanvien";
            this.cmbManhanvien.Size = new System.Drawing.Size(350, 36);
            this.cmbManhanvien.TabIndex = 40;
            // 
            // dtpNgaylaphd
            // 
            this.dtpNgaylaphd.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpNgaylaphd.Location = new System.Drawing.Point(135, 239);
            this.dtpNgaylaphd.Name = "dtpNgaylaphd";
            this.dtpNgaylaphd.Size = new System.Drawing.Size(350, 27);
            this.dtpNgaylaphd.TabIndex = 38;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(623, 93);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(107, 19);
            this.label3.TabIndex = 37;
            this.label3.Text = "Mã nhân viên";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(623, 174);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(119, 19);
            this.label2.TabIndex = 36;
            this.label2.Text = "Mã khách hàng";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(38, 174);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(79, 19);
            this.label9.TabIndex = 35;
            this.label9.Text = "Tổng tiền";
            // 
            // txtMahoadon
            // 
            this.txtMahoadon.Location = new System.Drawing.Point(135, 90);
            this.txtMahoadon.Multiline = true;
            this.txtMahoadon.Name = "txtMahoadon";
            this.txtMahoadon.Size = new System.Drawing.Size(350, 30);
            this.txtMahoadon.TabIndex = 31;
            // 
            // txtTongtien
            // 
            this.txtTongtien.Location = new System.Drawing.Point(135, 165);
            this.txtTongtien.Multiline = true;
            this.txtTongtien.Name = "txtTongtien";
            this.txtTongtien.Size = new System.Drawing.Size(350, 30);
            this.txtTongtien.TabIndex = 32;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(43, 239);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(73, 19);
            this.label5.TabIndex = 34;
            this.label5.Text = "Ngày lập";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(38, 93);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(94, 19);
            this.label1.TabIndex = 33;
            this.label1.Text = "Mã hóa đơn";
            // 
            // dgvHoadon
            // 
            this.dgvHoadon.BackgroundColor = System.Drawing.Color.White;
            this.dgvHoadon.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvHoadon.Location = new System.Drawing.Point(13, 530);
            this.dgvHoadon.Name = "dgvHoadon";
            this.dgvHoadon.RowHeadersWidth = 51;
            this.dgvHoadon.RowTemplate.Height = 24;
            this.dgvHoadon.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvHoadon.Size = new System.Drawing.Size(1412, 289);
            this.dgvHoadon.TabIndex = 50;
            this.dgvHoadon.SelectionChanged += new System.EventHandler(this.dgvHoadon_SelectionChanged);
            // 
            // btnLuuhd
            // 
            this.btnLuuhd.BorderRadius = 20;
            this.btnLuuhd.BorderThickness = 1;
            this.btnLuuhd.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnLuuhd.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnLuuhd.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnLuuhd.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnLuuhd.FillColor = System.Drawing.Color.LightCoral;
            this.btnLuuhd.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLuuhd.ForeColor = System.Drawing.Color.White;
            this.btnLuuhd.HoverState.BorderColor = System.Drawing.Color.LightCoral;
            this.btnLuuhd.HoverState.FillColor = System.Drawing.Color.White;
            this.btnLuuhd.HoverState.ForeColor = System.Drawing.Color.LightCoral;
            this.btnLuuhd.Location = new System.Drawing.Point(877, 438);
            this.btnLuuhd.Name = "btnLuuhd";
            this.btnLuuhd.Size = new System.Drawing.Size(200, 60);
            this.btnLuuhd.TabIndex = 56;
            this.btnLuuhd.Text = "Lưu";
            // 
            // btnXoahd
            // 
            this.btnXoahd.BorderRadius = 20;
            this.btnXoahd.BorderThickness = 1;
            this.btnXoahd.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnXoahd.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnXoahd.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnXoahd.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnXoahd.FillColor = System.Drawing.Color.LightCoral;
            this.btnXoahd.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXoahd.ForeColor = System.Drawing.Color.White;
            this.btnXoahd.HoverState.BorderColor = System.Drawing.Color.LightCoral;
            this.btnXoahd.HoverState.FillColor = System.Drawing.Color.White;
            this.btnXoahd.HoverState.ForeColor = System.Drawing.Color.LightCoral;
            this.btnXoahd.Location = new System.Drawing.Point(289, 438);
            this.btnXoahd.Name = "btnXoahd";
            this.btnXoahd.Size = new System.Drawing.Size(200, 60);
            this.btnXoahd.TabIndex = 53;
            this.btnXoahd.Text = "Xóa hóa đơn";
            // 
            // btnThemhd
            // 
            this.btnThemhd.BorderRadius = 20;
            this.btnThemhd.BorderThickness = 1;
            this.btnThemhd.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnThemhd.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnThemhd.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnThemhd.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnThemhd.FillColor = System.Drawing.Color.LightCoral;
            this.btnThemhd.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThemhd.ForeColor = System.Drawing.Color.White;
            this.btnThemhd.HoverState.BorderColor = System.Drawing.Color.LightCoral;
            this.btnThemhd.HoverState.FillColor = System.Drawing.Color.White;
            this.btnThemhd.HoverState.ForeColor = System.Drawing.Color.LightCoral;
            this.btnThemhd.Location = new System.Drawing.Point(11, 438);
            this.btnThemhd.Name = "btnThemhd";
            this.btnThemhd.Size = new System.Drawing.Size(200, 60);
            this.btnThemhd.TabIndex = 52;
            this.btnThemhd.Text = "Thêm hóa đơn";
            this.btnThemhd.Click += new System.EventHandler(this.btnThemhd_Click);
            // 
            // btnSuahd
            // 
            this.btnSuahd.BorderRadius = 20;
            this.btnSuahd.BorderThickness = 1;
            this.btnSuahd.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnSuahd.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnSuahd.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnSuahd.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnSuahd.FillColor = System.Drawing.Color.LightCoral;
            this.btnSuahd.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSuahd.ForeColor = System.Drawing.Color.White;
            this.btnSuahd.HoverState.BorderColor = System.Drawing.Color.LightCoral;
            this.btnSuahd.HoverState.FillColor = System.Drawing.Color.White;
            this.btnSuahd.HoverState.ForeColor = System.Drawing.Color.LightCoral;
            this.btnSuahd.Location = new System.Drawing.Point(596, 438);
            this.btnSuahd.Name = "btnSuahd";
            this.btnSuahd.Size = new System.Drawing.Size(200, 60);
            this.btnSuahd.TabIndex = 55;
            this.btnSuahd.Text = "Sửa hóa đơn";
            // 
            // btnHuyhd
            // 
            this.btnHuyhd.BorderRadius = 20;
            this.btnHuyhd.BorderThickness = 1;
            this.btnHuyhd.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnHuyhd.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnHuyhd.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnHuyhd.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnHuyhd.FillColor = System.Drawing.Color.LightCoral;
            this.btnHuyhd.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHuyhd.ForeColor = System.Drawing.Color.White;
            this.btnHuyhd.HoverState.BorderColor = System.Drawing.Color.LightCoral;
            this.btnHuyhd.HoverState.FillColor = System.Drawing.Color.White;
            this.btnHuyhd.HoverState.ForeColor = System.Drawing.Color.LightCoral;
            this.btnHuyhd.Location = new System.Drawing.Point(1158, 438);
            this.btnHuyhd.Name = "btnHuyhd";
            this.btnHuyhd.Size = new System.Drawing.Size(200, 60);
            this.btnHuyhd.TabIndex = 54;
            this.btnHuyhd.Text = "Hủy";
            // 
            // Hoadon
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1436, 818);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.guna2GroupBox1);
            this.Controls.Add(this.dgvHoadon);
            this.Controls.Add(this.btnLuuhd);
            this.Controls.Add(this.btnXoahd);
            this.Controls.Add(this.btnThemhd);
            this.Controls.Add(this.btnSuahd);
            this.Controls.Add(this.btnHuyhd);
            this.Name = "Hoadon";
            this.Text = "Hóa đơn";
            this.guna2GroupBox1.ResumeLayout(false);
            this.guna2GroupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHoadon)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label8;
        private Guna.UI2.WinForms.Guna2ComboBox cmbMakhachhang;
        private Guna.UI2.WinForms.Guna2GroupBox guna2GroupBox1;
        private Guna.UI2.WinForms.Guna2ComboBox cmbManhanvien;
        private System.Windows.Forms.DateTimePicker dtpNgaylaphd;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtMahoadon;
        private System.Windows.Forms.TextBox txtTongtien;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dgvHoadon;
        private Guna.UI2.WinForms.Guna2Button btnLuuhd;
        private Guna.UI2.WinForms.Guna2Button btnXoahd;
        private Guna.UI2.WinForms.Guna2Button btnThemhd;
        private Guna.UI2.WinForms.Guna2Button btnSuahd;
        private Guna.UI2.WinForms.Guna2Button btnHuyhd;
    }
}
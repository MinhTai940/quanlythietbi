﻿namespace DoAnCoSo
{
    partial class Sanpham
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Sanpham));
            this.label10 = new System.Windows.Forms.Label();
            this.txtMota = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtGiaban = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txtMasanpham = new System.Windows.Forms.TextBox();
            this.txtTensanpham = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtKichthuoc = new System.Windows.Forms.TextBox();
            this.txtSoluongton = new System.Windows.Forms.TextBox();
            this.txtMausac = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtMatheloai = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnTimkiemsp = new Guna.UI2.WinForms.Guna2ImageButton();
            this.txtTimkiemsanpham = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2GroupBox1 = new Guna.UI2.WinForms.Guna2GroupBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.btnSuasp = new Guna.UI2.WinForms.Guna2Button();
            this.btnTailaisp = new Guna.UI2.WinForms.Guna2Button();
            this.dgvHienthithongtinsp = new System.Windows.Forms.DataGridView();
            this.btnXoasp = new Guna.UI2.WinForms.Guna2Button();
            this.btnThemsp = new Guna.UI2.WinForms.Guna2Button();
            this.btnQuaylaisp = new Guna.UI2.WinForms.Guna2Button();
            this.guna2GroupBox1.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHienthithongtinsp)).BeginInit();
            this.SuspendLayout();
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(31, 176);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(94, 19);
            this.label10.TabIndex = 39;
            this.label10.Text = "Kích Thước";
            // 
            // txtMota
            // 
            this.txtMota.Location = new System.Drawing.Point(676, 116);
            this.txtMota.Multiline = true;
            this.txtMota.Name = "txtMota";
            this.txtMota.Size = new System.Drawing.Size(350, 30);
            this.txtMota.TabIndex = 27;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(31, 119);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(112, 19);
            this.label9.TabIndex = 38;
            this.label9.Text = "Tên sản phẩm ";
            // 
            // txtGiaban
            // 
            this.txtGiaban.Location = new System.Drawing.Point(676, 63);
            this.txtGiaban.Multiline = true;
            this.txtGiaban.Name = "txtGiaban";
            this.txtGiaban.Size = new System.Drawing.Size(350, 30);
            this.txtGiaban.TabIndex = 31;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(31, 229);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(97, 19);
            this.label8.TabIndex = 37;
            this.label8.Text = "Mã thể loại ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(555, 176);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(69, 19);
            this.label3.TabIndex = 34;
            this.label3.Text = "Màu sắc";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(555, 66);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(67, 19);
            this.label7.TabIndex = 36;
            this.label7.Text = "Giá bán";
            // 
            // txtMasanpham
            // 
            this.txtMasanpham.Location = new System.Drawing.Point(150, 66);
            this.txtMasanpham.Multiline = true;
            this.txtMasanpham.Name = "txtMasanpham";
            this.txtMasanpham.Size = new System.Drawing.Size(350, 30);
            this.txtMasanpham.TabIndex = 24;
            // 
            // txtTensanpham
            // 
            this.txtTensanpham.Location = new System.Drawing.Point(149, 119);
            this.txtTensanpham.Multiline = true;
            this.txtTensanpham.Name = "txtTensanpham";
            this.txtTensanpham.Size = new System.Drawing.Size(350, 30);
            this.txtTensanpham.TabIndex = 25;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(555, 119);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(52, 19);
            this.label5.TabIndex = 35;
            this.label5.Text = "Mô tả";
            // 
            // txtKichthuoc
            // 
            this.txtKichthuoc.Location = new System.Drawing.Point(149, 176);
            this.txtKichthuoc.Multiline = true;
            this.txtKichthuoc.Name = "txtKichthuoc";
            this.txtKichthuoc.Size = new System.Drawing.Size(350, 30);
            this.txtKichthuoc.TabIndex = 26;
            // 
            // txtSoluongton
            // 
            this.txtSoluongton.Location = new System.Drawing.Point(676, 226);
            this.txtSoluongton.Multiline = true;
            this.txtSoluongton.Name = "txtSoluongton";
            this.txtSoluongton.Size = new System.Drawing.Size(350, 30);
            this.txtSoluongton.TabIndex = 28;
            // 
            // txtMausac
            // 
            this.txtMausac.Location = new System.Drawing.Point(676, 173);
            this.txtMausac.Multiline = true;
            this.txtMausac.Name = "txtMausac";
            this.txtMausac.Size = new System.Drawing.Size(350, 30);
            this.txtMausac.TabIndex = 29;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(555, 229);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(102, 19);
            this.label2.TabIndex = 33;
            this.label2.Text = "Số lượng tồn";
            // 
            // txtMatheloai
            // 
            this.txtMatheloai.Location = new System.Drawing.Point(149, 229);
            this.txtMatheloai.Multiline = true;
            this.txtMatheloai.Name = "txtMatheloai";
            this.txtMatheloai.Size = new System.Drawing.Size(350, 30);
            this.txtMatheloai.TabIndex = 30;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(31, 66);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(105, 19);
            this.label1.TabIndex = 32;
            this.label1.Text = "Mã sản phẩm";
            // 
            // btnTimkiemsp
            // 
            this.btnTimkiemsp.CheckedState.ImageSize = new System.Drawing.Size(64, 64);
            this.btnTimkiemsp.HoverState.ImageSize = new System.Drawing.Size(64, 64);
            this.btnTimkiemsp.Image = ((System.Drawing.Image)(resources.GetObject("btnTimkiemsp.Image")));
            this.btnTimkiemsp.ImageOffset = new System.Drawing.Point(0, 0);
            this.btnTimkiemsp.ImageRotate = 0F;
            this.btnTimkiemsp.Location = new System.Drawing.Point(497, 23);
            this.btnTimkiemsp.Name = "btnTimkiemsp";
            this.btnTimkiemsp.PressedState.ImageSize = new System.Drawing.Size(64, 64);
            this.btnTimkiemsp.Size = new System.Drawing.Size(64, 54);
            this.btnTimkiemsp.TabIndex = 1;
            this.btnTimkiemsp.Click += new System.EventHandler(this.btnTimkiemsp_Click);
            // 
            // txtTimkiemsanpham
            // 
            this.txtTimkiemsanpham.BorderRadius = 15;
            this.txtTimkiemsanpham.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtTimkiemsanpham.DefaultText = "";
            this.txtTimkiemsanpham.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtTimkiemsanpham.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtTimkiemsanpham.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtTimkiemsanpham.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtTimkiemsanpham.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtTimkiemsanpham.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtTimkiemsanpham.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtTimkiemsanpham.Location = new System.Drawing.Point(26, 23);
            this.txtTimkiemsanpham.Name = "txtTimkiemsanpham";
            this.txtTimkiemsanpham.PasswordChar = '\0';
            this.txtTimkiemsanpham.PlaceholderText = "";
            this.txtTimkiemsanpham.SelectedText = "";
            this.txtTimkiemsanpham.Size = new System.Drawing.Size(456, 48);
            this.txtTimkiemsanpham.TabIndex = 0;
            // 
            // guna2GroupBox1
            // 
            this.guna2GroupBox1.Controls.Add(this.label10);
            this.guna2GroupBox1.Controls.Add(this.txtMota);
            this.guna2GroupBox1.Controls.Add(this.label9);
            this.guna2GroupBox1.Controls.Add(this.txtGiaban);
            this.guna2GroupBox1.Controls.Add(this.label8);
            this.guna2GroupBox1.Controls.Add(this.label3);
            this.guna2GroupBox1.Controls.Add(this.label7);
            this.guna2GroupBox1.Controls.Add(this.txtMasanpham);
            this.guna2GroupBox1.Controls.Add(this.txtTensanpham);
            this.guna2GroupBox1.Controls.Add(this.label5);
            this.guna2GroupBox1.Controls.Add(this.txtKichthuoc);
            this.guna2GroupBox1.Controls.Add(this.txtSoluongton);
            this.guna2GroupBox1.Controls.Add(this.txtMausac);
            this.guna2GroupBox1.Controls.Add(this.label2);
            this.guna2GroupBox1.Controls.Add(this.txtMatheloai);
            this.guna2GroupBox1.Controls.Add(this.label1);
            this.guna2GroupBox1.CustomBorderColor = System.Drawing.Color.LightCoral;
            this.guna2GroupBox1.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.guna2GroupBox1.ForeColor = System.Drawing.Color.White;
            this.guna2GroupBox1.Location = new System.Drawing.Point(12, 172);
            this.guna2GroupBox1.Name = "guna2GroupBox1";
            this.guna2GroupBox1.Size = new System.Drawing.Size(1412, 288);
            this.guna2GroupBox1.TabIndex = 53;
            this.guna2GroupBox1.Text = "Thông Tin Sản Phẩm";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btnTimkiemsp);
            this.panel1.Controls.Add(this.txtTimkiemsanpham);
            this.panel1.Location = new System.Drawing.Point(12, 62);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(665, 93);
            this.panel1.TabIndex = 52;
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label4.Location = new System.Drawing.Point(545, 9);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(349, 61);
            this.label4.TabIndex = 51;
            this.label4.Text = "Quản lý sản phẩm";
            // 
            // btnSuasp
            // 
            this.btnSuasp.BorderRadius = 20;
            this.btnSuasp.BorderThickness = 1;
            this.btnSuasp.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnSuasp.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnSuasp.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnSuasp.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnSuasp.FillColor = System.Drawing.Color.LightCoral;
            this.btnSuasp.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSuasp.ForeColor = System.Drawing.Color.White;
            this.btnSuasp.HoverState.BorderColor = System.Drawing.Color.LightCoral;
            this.btnSuasp.HoverState.FillColor = System.Drawing.Color.White;
            this.btnSuasp.HoverState.ForeColor = System.Drawing.Color.LightCoral;
            this.btnSuasp.Location = new System.Drawing.Point(602, 481);
            this.btnSuasp.Name = "btnSuasp";
            this.btnSuasp.Size = new System.Drawing.Size(200, 60);
            this.btnSuasp.TabIndex = 49;
            this.btnSuasp.Text = "Sửa sản phẩm";
            this.btnSuasp.Click += new System.EventHandler(this.btnSuasp_Click);
            // 
            // btnTailaisp
            // 
            this.btnTailaisp.BorderRadius = 20;
            this.btnTailaisp.BorderThickness = 1;
            this.btnTailaisp.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnTailaisp.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnTailaisp.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnTailaisp.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnTailaisp.FillColor = System.Drawing.Color.LightCoral;
            this.btnTailaisp.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTailaisp.ForeColor = System.Drawing.Color.White;
            this.btnTailaisp.HoverState.BorderColor = System.Drawing.Color.LightCoral;
            this.btnTailaisp.HoverState.FillColor = System.Drawing.Color.White;
            this.btnTailaisp.HoverState.ForeColor = System.Drawing.Color.LightCoral;
            this.btnTailaisp.Location = new System.Drawing.Point(877, 481);
            this.btnTailaisp.Name = "btnTailaisp";
            this.btnTailaisp.Size = new System.Drawing.Size(200, 60);
            this.btnTailaisp.TabIndex = 50;
            this.btnTailaisp.Text = "Tải lại";
            this.btnTailaisp.Click += new System.EventHandler(this.btnTailaisp_Click);
            // 
            // dgvHienthithongtinsp
            // 
            this.dgvHienthithongtinsp.BackgroundColor = System.Drawing.Color.White;
            this.dgvHienthithongtinsp.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvHienthithongtinsp.Location = new System.Drawing.Point(12, 563);
            this.dgvHienthithongtinsp.Name = "dgvHienthithongtinsp";
            this.dgvHienthithongtinsp.RowHeadersWidth = 51;
            this.dgvHienthithongtinsp.RowTemplate.Height = 24;
            this.dgvHienthithongtinsp.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvHienthithongtinsp.Size = new System.Drawing.Size(1412, 289);
            this.dgvHienthithongtinsp.TabIndex = 45;
            this.dgvHienthithongtinsp.SelectionChanged += new System.EventHandler(this.dgvHienthithongtinsp_SelectionChanged);
            // 
            // btnXoasp
            // 
            this.btnXoasp.BorderRadius = 20;
            this.btnXoasp.BorderThickness = 1;
            this.btnXoasp.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnXoasp.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnXoasp.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnXoasp.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnXoasp.FillColor = System.Drawing.Color.LightCoral;
            this.btnXoasp.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXoasp.ForeColor = System.Drawing.Color.White;
            this.btnXoasp.HoverState.BorderColor = System.Drawing.Color.LightCoral;
            this.btnXoasp.HoverState.FillColor = System.Drawing.Color.White;
            this.btnXoasp.HoverState.ForeColor = System.Drawing.Color.LightCoral;
            this.btnXoasp.Location = new System.Drawing.Point(324, 481);
            this.btnXoasp.Name = "btnXoasp";
            this.btnXoasp.Size = new System.Drawing.Size(200, 60);
            this.btnXoasp.TabIndex = 47;
            this.btnXoasp.Text = "Xóa sản phẩm";
            this.btnXoasp.Click += new System.EventHandler(this.btnXoasp_Click);
            // 
            // btnThemsp
            // 
            this.btnThemsp.BorderRadius = 20;
            this.btnThemsp.BorderThickness = 1;
            this.btnThemsp.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnThemsp.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnThemsp.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnThemsp.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnThemsp.FillColor = System.Drawing.Color.LightCoral;
            this.btnThemsp.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThemsp.ForeColor = System.Drawing.Color.White;
            this.btnThemsp.HoverState.BorderColor = System.Drawing.Color.LightCoral;
            this.btnThemsp.HoverState.FillColor = System.Drawing.Color.White;
            this.btnThemsp.HoverState.ForeColor = System.Drawing.Color.LightCoral;
            this.btnThemsp.Location = new System.Drawing.Point(37, 481);
            this.btnThemsp.Name = "btnThemsp";
            this.btnThemsp.Size = new System.Drawing.Size(200, 60);
            this.btnThemsp.TabIndex = 46;
            this.btnThemsp.Text = "Thêm sản phẩm";
            this.btnThemsp.Click += new System.EventHandler(this.btnThemsp_Click);
            // 
            // btnQuaylaisp
            // 
            this.btnQuaylaisp.BorderRadius = 20;
            this.btnQuaylaisp.BorderThickness = 1;
            this.btnQuaylaisp.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnQuaylaisp.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnQuaylaisp.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnQuaylaisp.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnQuaylaisp.FillColor = System.Drawing.Color.LightCoral;
            this.btnQuaylaisp.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnQuaylaisp.ForeColor = System.Drawing.Color.White;
            this.btnQuaylaisp.HoverState.BorderColor = System.Drawing.Color.LightCoral;
            this.btnQuaylaisp.HoverState.FillColor = System.Drawing.Color.White;
            this.btnQuaylaisp.HoverState.ForeColor = System.Drawing.Color.LightCoral;
            this.btnQuaylaisp.Location = new System.Drawing.Point(1175, 481);
            this.btnQuaylaisp.Name = "btnQuaylaisp";
            this.btnQuaylaisp.Size = new System.Drawing.Size(200, 60);
            this.btnQuaylaisp.TabIndex = 48;
            this.btnQuaylaisp.Text = "Quay lại";
            this.btnQuaylaisp.Click += new System.EventHandler(this.btnQuaylaisp_Click);
            // 
            // Sanpham
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1436, 818);
            this.Controls.Add(this.guna2GroupBox1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.btnSuasp);
            this.Controls.Add(this.btnTailaisp);
            this.Controls.Add(this.dgvHienthithongtinsp);
            this.Controls.Add(this.btnXoasp);
            this.Controls.Add(this.btnThemsp);
            this.Controls.Add(this.btnQuaylaisp);
            this.Name = "Sanpham";
            this.Text = "Sản phẩm";
            this.guna2GroupBox1.ResumeLayout(false);
            this.guna2GroupBox1.PerformLayout();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvHienthithongtinsp)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtMota;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtGiaban;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtMasanpham;
        private System.Windows.Forms.TextBox txtTensanpham;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtKichthuoc;
        private System.Windows.Forms.TextBox txtSoluongton;
        private System.Windows.Forms.TextBox txtMausac;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtMatheloai;
        private System.Windows.Forms.Label label1;
        private Guna.UI2.WinForms.Guna2ImageButton btnTimkiemsp;
        private Guna.UI2.WinForms.Guna2TextBox txtTimkiemsanpham;
        private Guna.UI2.WinForms.Guna2GroupBox guna2GroupBox1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label4;
        private Guna.UI2.WinForms.Guna2Button btnSuasp;
        private Guna.UI2.WinForms.Guna2Button btnTailaisp;
        private System.Windows.Forms.DataGridView dgvHienthithongtinsp;
        private Guna.UI2.WinForms.Guna2Button btnXoasp;
        private Guna.UI2.WinForms.Guna2Button btnThemsp;
        private Guna.UI2.WinForms.Guna2Button btnQuaylaisp;
    }
}
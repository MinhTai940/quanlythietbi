﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DoAnCoSo
{
    public partial class Nhacungcap : Form
    {
        string connectionString = "Data Source=DESKTOP-DL8SVNN\\PHUONGANH;Initial Catalog=QuanLyThoiTrangNu;User ID=sa;Password=12345678;Integrated Security=True";
        public Nhacungcap()
        {
            InitializeComponent();
            Hienthithongnhacungcap();
        }
        private void Hienthithongnhacungcap()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT * FROM Nha_Cung_Cap";

                    using (SqlDataAdapter adapter = new SqlDataAdapter(query, connection))
                    {
                        DataSet dataSet = new DataSet();
                        adapter.Fill(dataSet);
                        dgvHienthithongtinncc.DataSource = dataSet.Tables[0];
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi hiển thị danh sách nhà cung cấp: " + ex.Message);
            }
        }

        private void btnThemncc_Click(object sender, EventArgs e)
        {
            try
            {
                string maNhaCungCap = txtManhacungcap.Text.Trim();
                string tenNhaCungCap = txtTennhacungcap.Text.Trim();
                string soDienThoai = txtSdtnhacungcap.Text.Trim();
                string email = txtEmailnhacungcap.Text.Trim();
                string diaChi = txtDiachinhacungcap.Text.Trim();
                
                if (string.IsNullOrEmpty(maNhaCungCap) || string.IsNullOrEmpty(tenNhaCungCap) || string.IsNullOrEmpty(soDienThoai) || string.IsNullOrEmpty(diaChi) || string.IsNullOrEmpty(email))
                {
                    MessageBox.Show("Vui lòng nhập đầy đủ thông tin bắt buộc!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // Kiểm tra định dạng số điện thoại: chỉ chứa số và độ dài từ 9-11
                if (!System.Text.RegularExpressions.Regex.IsMatch(soDienThoai, @"^\d{9,11}$"))
                {
                    MessageBox.Show("Số điện thoại không hợp lệ! Vui lòng nhập 9-11 chữ số.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // Kiểm tra định dạng email
                if (!System.Text.RegularExpressions.Regex.IsMatch(email, @"^[^@\s]+@[^@\s]+\.[^@\s]+$"))
                {
                    MessageBox.Show("Email không hợp lệ! Vui lòng nhập đúng định dạng (vd: ten@gmail.com).", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    string checkQuery = "SELECT COUNT(*) FROM Nha_Cung_Cap WHERE Ma_Nha_Cung_Cap = @Ma_Nha_Cung_Cap";
                    using (SqlCommand checkCommand = new SqlCommand(checkQuery, connection))
                    {
                        checkCommand.Parameters.AddWithValue("@Ma_Nha_Cung_Cap", maNhaCungCap);
                        int count = (int)checkCommand.ExecuteScalar();
                        if (count > 0)
                        {
                            MessageBox.Show("Mã nhà cung cấp đã tồn tại! Vui lòng nhập mã khác.");
                            return;
                        }
                    }

                    string query = "INSERT INTO Nha_Cung_Cap (Ma_Nha_Cung_Cap, Ten_Nha_Cung_Cap, So_Dien_Thoai, Email, Dia_Chi) " +
                                    "VALUES (@Ma_Nha_Cung_Cap, @Ten_Nha_Cung_Cap, @So_Dien_Thoai, @Email, @Dia_Chi)";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@Ma_Nha_Cung_Cap", maNhaCungCap);
                        command.Parameters.AddWithValue("@Ten_Nha_Cung_Cap", tenNhaCungCap);
                        command.Parameters.AddWithValue("@So_Dien_Thoai", soDienThoai);
                        command.Parameters.AddWithValue("@Email", email);
                        command.Parameters.AddWithValue("@Dia_Chi", diaChi); 
                        command.ExecuteNonQuery();
                    }
                    MessageBox.Show("Thêm nhà cung cấp thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Hienthithongnhacungcap();
                    ClearFormNhacungcap();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi thêm nhà cung cấp: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void ClearFormNhacungcap()
        {
            txtManhacungcap.Text = "";
            txtTennhacungcap.Text = "";
            txtSdtnhacungcap.Text = "";
            txtEmailnhacungcap.Text = "";
            txtDiachinhacungcap.Text = "";

            txtManhacungcap.ReadOnly = false;
        }

        private void btnXoancc_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvHienthithongtinncc.SelectedRows.Count == 0)
                {
                    MessageBox.Show("Vui lòng chọn nhà cung cấp cần xóa!");
                    return;
                }
                DialogResult result = MessageBox.Show("Bạn có chắc chắn muốn xóa dữ liệu không?", "Xác nhận xóa", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    string maNhaCungCap = dgvHienthithongtinncc.SelectedRows[0].Cells["Ma_Nha_Cung_Cap"].Value.ToString();
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();

                        string query = "DELETE FROM Nha_Cung_Cap WHERE Ma_Nha_Cung_Cap = @Ma_Nha_Cung_Cap";
                        using (SqlCommand command = new SqlCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("@Ma_Nha_Cung_Cap", maNhaCungCap);
                            command.ExecuteNonQuery();
                        }
                    }
                    MessageBox.Show("Xóa dữ liệu thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Hienthithongnhacungcap();
                    ClearFormNhacungcap();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi xóa dữ liệu: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnSuancc_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvHienthithongtinncc.SelectedRows.Count == 0)
                {
                    MessageBox.Show("Vui lòng chọn nhà cung cấp cần sửa!");
                    return;
                }
                DialogResult result = MessageBox.Show("Bạn có chắc chắn muốn sửa dữ liệu không?", "Xác nhận sửa", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    string maNhaCungCap = dgvHienthithongtinncc.SelectedRows[0].Cells["Ma_Nha_Cung_Cap"].Value.ToString();
                    string tenNhaCungCap = txtTennhacungcap.Text.Trim();
                    string soDienThoai = txtSdtnhacungcap.Text.Trim();
                    string email = txtEmailnhacungcap.Text.Trim();
                    string diaChi = txtDiachinhacungcap.Text.Trim();

                    if (string.IsNullOrEmpty(maNhaCungCap) || string.IsNullOrEmpty(tenNhaCungCap) || string.IsNullOrEmpty(soDienThoai) || string.IsNullOrEmpty(email) || string.IsNullOrEmpty(diaChi))
                    {
                        MessageBox.Show("Vui lòng nhập đầy đủ thông tin bắt buộc!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();

                        string query = "UPDATE Nha_Cung_Cap SET Ten_Nha_Cung_Cap = @Ten_Nha_Cung_Cap, So_Dien_Thoai = @So_Dien_Thoai, Email = @Email, Dia_Chi = @Dia_Chi " +
                                       "WHERE Ma_Nha_Cung_Cap = @Ma_Nha_Cung_Cap";
                        using (SqlCommand command = new SqlCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("@Ma_Nha_Cung_Cap", maNhaCungCap);
                            command.Parameters.AddWithValue("@Ten_Nha_Cung_Cap", tenNhaCungCap);
                            command.Parameters.AddWithValue("@So_Dien_Thoai", soDienThoai);
                            command.Parameters.AddWithValue("@Email", email);
                            command.Parameters.AddWithValue("@Dia_Chi", diaChi);
                            command.ExecuteNonQuery();
                        }
                        MessageBox.Show("Sửa dữ liệu thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        Hienthithongnhacungcap();
                        ClearFormNhacungcap();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi sửa dữ liệu: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void btnTimkiemncc_Click(object sender, EventArgs e)
        {
            try
            {
                string maNhaCungCap = txtTimkiemnhacungcap.Text.Trim();
                if (string.IsNullOrEmpty(maNhaCungCap))
                {
                    MessageBox.Show("Vui lòng nhập mã nhà cung cấp để tìm kiếm!");
                    return;
                }

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    string query = "SELECT ncc.Ma_Nha_Cung_Cap, ncc.Ten_Nha_Cung_Cap, ncc.So_Dien_Thoai, ncc.Email, ncc.Dia_Chi " +
                                   "FROM Nha_Cung_Cap ncc " +
                                   "WHERE ncc.Ma_Nha_Cung_Cap LIKE @Ma_Nha_Cung_Cap";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@Ma_Nha_Cung_Cap", "%" + maNhaCungCap + "%");
                        using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                        {
                            DataSet dataSet = new DataSet();
                            adapter.Fill(dataSet);
                            dgvHienthithongtinncc.DataSource = dataSet.Tables[0];
                        }
                    }
                }
                if (dgvHienthithongtinncc.Rows.Count == 0 || dgvHienthithongtinncc.Rows[0].IsNewRow)
                {
                    MessageBox.Show("Không tìm thấy mã nhà cung cấp: " + maNhaCungCap + "!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi tìm kiếm dữ liệu: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnTailaincc_Click(object sender, EventArgs e)
        {
            Hienthithongnhacungcap();
            ClearFormNhacungcap();
            txtTimkiemnhacungcap.Text = "";
        }

        private void btnQuaylaincc_Click(object sender, EventArgs e)
        {
            Caidat caidat = new Caidat();
            caidat.Show();
        }

        private void dgvHienthithongtinncc_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvHienthithongtinncc.SelectedRows.Count == 0) return;

            DataGridViewRow row = dgvHienthithongtinncc.SelectedRows[0];

            txtManhacungcap.Text = row.Cells["Ma_Nha_Cung_Cap"].Value?.ToString();
            txtTennhacungcap.Text = row.Cells["Ten_Nha_Cung_Cap"].Value?.ToString();
            txtSdtnhacungcap.Text = row.Cells["So_Dien_Thoai"].Value?.ToString();
            txtEmailnhacungcap.Text = row.Cells["Email"].Value?.ToString();
            txtDiachinhacungcap.Text = row.Cells["Dia_Chi"].Value?.ToString();

            txtManhacungcap.ReadOnly = true;
        }
    }
}
